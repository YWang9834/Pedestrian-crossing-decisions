import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import gym
from matplotlib.gridspec import GridSpec
from Load_Exp import LoadExpCIT
from Load_Exp import LoadExpGap
import os
# Load Exp data
SeperatePlot = False
plot_dir = 'Plot'
os.makedirs(plot_dir, exist_ok=True)
green = (89 / 255, 169 / 255, 90 / 255)
orange = (247 / 255, 144 / 255, 61 / 255)
blue = (77 / 255, 133 / 255, 189 / 255)
def CITPlot(ax1,ax2,ax3,ax4,ax5,ax6):
    path = "./Exp_data"
    crossname = path+'/d2p_cross_times_uk.csv'
    x6_2_0_exp, x6_4_0_exp, x6_6_0_exp, x13_2_0_exp, x13_4_0_exp, x13_6_0_exp,y6_2_0_exp, y6_4_0_exp, y6_6_0_exp, y13_2_0_exp, y13_4_0_exp, y13_6_0_exp, \
               x13_4_4_exp,x13_2_4_exp, x13_6_4_exp,x6_4_4_exp,x6_2_4_exp,x6_6_4_exp, x13_2_8_exp, x13_4_8_exp,\
               y13_4_4_exp,y13_2_4_exp, y13_6_4_exp,y6_4_4_exp,y6_2_4_exp,y6_6_4_exp, y13_2_8_exp, y13_4_8_exp= LoadExpCIT(crossname)
    # if SeperatePlot:
    #     fig = plt.figure(figsize=(10, 5))
    #     gs = GridSpec(2, 9, figure=fig)
    #     # EXP
    #     ax1 = fig.add_subplot(gs[0, 0:3], label="1")
    #     ax2 = fig.add_subplot(gs[0, 3:6], label="1")
    #     ax3 = fig.add_subplot(gs[0, 6:9], label="1")
    #
    #     # Ideal
    #     ax4 = fig.add_subplot(gs[1, 0:3], label="1")
    #     ax5 = fig.add_subplot(gs[1, 3:6], label="1")
    #     ax6 = fig.add_subplot(gs[1, 6:9], label="1")
    #     # ax8 = fig.add_subplot(gs[1, 9:12], label="1")
    #

    rightlabel_font = 17
    tick_size = 13
    leftlabel_font = 16
    title_font = 18
    legend_size = 14
    linewidth = 3
    alpha = 0.8
    # plt.xlabel("Time (s)", size=title_font, loc = 'center')
    # Plot EXP(1-4)
    x2=[2.3,2.3]
    x4 = [4.6, 4.6]
    x6 = [6.9, 6.9]
    y = [0, 1.1]


    ax1.plot(x6_2_0_exp, y6_2_0_exp,alpha=alpha, color=blue,linewidth = linewidth)
    ax1.plot(x13_2_0_exp, y13_2_0_exp, alpha=alpha, color=orange,linewidth = linewidth)
    ax1.plot(x2, y, alpha=0.7, color='k',linewidth = 2,linestyle='--')
    ax2.plot(x6_4_0_exp, y6_4_0_exp,alpha=alpha, color=blue,linewidth = linewidth)
    ax2.plot(x13_4_0_exp, y13_4_0_exp, alpha=alpha, color=orange,linewidth = linewidth)
    ax2.plot(x4, y, alpha=0.7, color='k', linewidth=2,linestyle='--')
    ax3.plot(x6_6_0_exp, y6_6_0_exp, alpha=alpha, color=blue, label='6.9 m/s',linewidth = linewidth)
    ax3.plot(x13_6_0_exp, y13_6_0_exp, alpha=alpha, color=orange, label='13.9 m/s',linewidth = linewidth)
    ax3.plot(x6, y, alpha=0.7, color='k', linewidth=2,linestyle='--')

    ax3.legend(prop={'size': legend_size},loc='lower right', bbox_to_anchor=(1.06,-0.04), framealpha=0.1)
    ax4.plot(x6_2_4_exp, y6_2_4_exp,alpha=alpha, color=blue,label='6.9 m/s; stop 4m',linewidth = linewidth)
    ax4.plot(x13_2_4_exp, y13_2_4_exp, alpha=alpha, color=orange,label='13.9 m/s; stop 4m',linewidth = linewidth)
    ax4.plot(x13_2_8_exp, y13_2_8_exp, alpha=0.6, color='grey',label='13.9 m/s; stop 8m',linewidth = 4)
    # ax4.plot(x2, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax5.plot(x6_4_4_exp, y6_4_4_exp,alpha=alpha, color=blue,label='6.9 m/s; stop 4m',linewidth = linewidth)
    ax5.plot(x13_4_4_exp, y13_4_4_exp, alpha=alpha, color=orange,label='13.9 m/s; stop 4m',linewidth = linewidth)
    ax5.plot(x13_4_8_exp, y13_4_8_exp, alpha=0.6, color='grey',label='13.9 m/s; stop 8m',linewidth = 4)
    # ax5.plot(x4, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax6.plot(x6_6_4_exp, y6_6_4_exp, alpha=alpha, color=blue, label='6.9 m/s; stop 4m',linewidth = linewidth)
    ax6.plot(x13_6_4_exp, y13_6_4_exp, alpha=alpha, color=orange, label='13.9 m/s; stop 4m',linewidth = linewidth)
    # ax6.plot(x6, y, alpha=alpha, color='grey', linewidth=linewidth)
    # ax4.legend(prop={'size': legend_size},loc='lower right')
    ax5.legend(prop={'size': legend_size},loc='lower right', bbox_to_anchor=(1.065,-0.04),framealpha=0.1)
    # ax6.legend(prop={'size': legend_size},loc='lower right')
    ax3.set_ylabel('Constant-speed', fontsize=rightlabel_font)
    ax6.set_ylabel('Yielding', fontsize=rightlabel_font)
    CIT_plotname = f'Exp_CIT.png'
    ax3.annotate('(b)', xy=(1.3, 0.4), xycoords='axes fraction', fontsize=title_font,
                 xytext=(-5, 5), textcoords='offset points', ha='right', va='bottom')
    ax6.annotate('(c)', xy=(1.3, 0.4), xycoords='axes fraction', fontsize=title_font,
                 xytext=(-5, 5), textcoords='offset points', ha='right', va='bottom')

    ax1.set_title('Initial TTA: 2.3 s', fontsize=title_font)
    ax2.set_title('Initial TTA: 4.6 s', fontsize=title_font)
    ax3.set_title('Initial TTA: 6.9 s', fontsize=title_font)

    ax1.set_xlim(0, 15)
    ax1.set_ylim(0, 1.1)
    ax2.set_xlim(0, 15)
    ax2.set_ylim(0, 1.1)
    ax3.set_xlim(0, 15)
    ax3.set_ylim(0, 1.1)
    ax4.set_xlim(0, 15)
    ax4.set_ylim(0, 1.1)
    ax5.set_xlim(0, 15)
    ax5.set_ylim(0, 1.1)
    ax6.set_xlim(0, 15)
    ax6.set_ylim(0, 1.1)

    ax1.yaxis.set_tick_params(labelsize=tick_size)
    ax1.xaxis.set_ticklabels([])
    ax2.yaxis.set_ticklabels([])
    ax2.xaxis.set_ticklabels([])
    ax3.yaxis.set_ticklabels([])
    ax3.xaxis.set_ticklabels([])
    # ax4.set_xticks([ 0,2, 4, 6, 8, 10,12,14])

    ax4.xaxis.set_tick_params(labelsize=tick_size)
    ax4.yaxis.set_tick_params(labelsize=tick_size)
    ax5.yaxis.set_ticklabels([])
    ax5.xaxis.set_tick_params(labelsize=tick_size)
    # ax5.set_xticks([ 0,2, 4, 6, 8, 10,12,14])

    ax6.yaxis.set_ticklabels([])
    ax6.xaxis.set_tick_params(labelsize=tick_size)
    # ax6.set_xticks([ 0,2, 4, 6, 8, 10,12,14])

    ax1.set_ylabel('Cumulative probability', fontsize=rightlabel_font)
    # ax1.yaxis.set_label_coords(1, 1)  # Adjust the first value as needed

    ax1.yaxis.set_label_coords(-0.17, -0.1)
    ax3.yaxis.set_label_position("right")
    ax6.yaxis.set_label_position("right")
    ax5.set_xlabel("Time in trial (s)", size=title_font)
    ax1.xaxis.set_ticklabels([])
    ax2.xaxis.set_ticklabels([])
    ax3.xaxis.set_ticklabels([])
    ax1.set_xlim(0, 16)  # Increase the maximum limit
    ax2.set_xlim(0, 16)  # Decrease the minimum limit
    ax3.set_xlim(0, 16)  # Decrease the minimum limit
    ax4.set_xlim(0, 16)  # Increase the maximum limit
    ax5.set_xlim(0, 16)  # Decrease the minimum limit
    ax5.set_xlim(0, 16)  # Decrease the minimum limit

    # if SeperatePlot:
    #     CIT_plot = os.path.join(plot_dir, CIT_plotname)
    #     plt.savefig(CIT_plot,dpi=300, bbox_inches = 'tight')
    # # plt.show()

def GapPlot(ax):
    title_font = 18
    rightlabel_font = 18
    tick_size = 13
    legend_size = 15
    linewidth = 3
    path = "./Exp_data"
    crossname = path + '/d2p_cross_times_uk.csv'
    acc6_exp, acc13_exp, gap = LoadExpGap(crossname)
    # if SeperatePlot:
    #     fig = plt.figure(figsize=(4, 4))
    #     gs = GridSpec(1, 1, figure=fig)
    #     ax = fig.add_subplot(gs[0, 0], label="1")

    # ax.scatter(gap, acc6_exp[0:3],  alpha=0.75,c=blue, marker='o')
    # ax.scatter(gap, acc13_exp[0:3], alpha=0.75, c=orange, marker='o')
    ax.plot(gap, acc6_exp[0:3], alpha=0.75, c=blue, marker='o', label='6.9 m/s', linewidth=linewidth)
    ax.plot(gap, acc13_exp[0:3], alpha=0.75, c=orange, marker='o', label='13.9 m/s', linewidth=linewidth)
    ax.xaxis.set_tick_params(labelsize=tick_size)
    ax.yaxis.set_tick_params(labelsize=tick_size)
    ax.set_ylabel('Gap acceptance rate', fontsize=rightlabel_font)
    ax.yaxis.set_label_position("left")
    ax.set_xlabel("Initial TTA (s)", size=title_font)
    ax.set_yticks([ 0.2, 0.4, 0.6, 0.8, 1.0])
    ax.set_xticks([ 2.3, 4.6, 6.9])
    ax.set_title('Constant-speed', fontsize=title_font)

    ax.legend(prop={'size': legend_size}, loc='lower right',bbox_to_anchor=(1.065,-0.04), framealpha=0.1)
    ax.annotate('(a)', xy=(-0.25, 0.45), xycoords='axes fraction', fontsize=title_font,
                xytext=(-5, 5), textcoords='offset points', ha='right', va='bottom')

    if SeperatePlot:
        gap_plotname = f'Exp_Gap.png'
        gap_plot = os.path.join(plot_dir, gap_plotname)
        plt.savefig(gap_plot, dpi=300, bbox_inches='tight')
        plt.show()

fig = plt.figure(figsize=(15, 6))
gs = GridSpec(4, 13, figure=fig)

# Subplots for Gap Plot
ax = fig.add_subplot(gs[1:3, 0:3])

# Subplots for CIT Plot
ax1 = fig.add_subplot(gs[0:2, 4:7])
ax2 = fig.add_subplot(gs[0:2, 7:10])
ax3 = fig.add_subplot(gs[0:2, 10:13])
ax4 = fig.add_subplot(gs[2:4, 4:7])
ax5 = fig.add_subplot(gs[2:4, 7:10])
ax6 = fig.add_subplot(gs[2:4, 10:13])


CITPlot(ax1, ax2, ax3, ax4, ax5, ax6)
GapPlot(ax)
combined_plotname = 'Exp_plot.png'

combined_plot = os.path.join(plot_dir, combined_plotname)
plt.savefig(combined_plot, dpi=300, bbox_inches='tight')
# plt.tight_layout()

plt.show()