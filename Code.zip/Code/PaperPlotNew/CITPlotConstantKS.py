import matplotlib.pyplot as plt
import numpy as np
import gym
from matplotlib.gridspec import GridSpec
import pandas as pd
import os
import seaborn as sns
from scipy.stats import ks_2samp
orange = (247 / 255, 144 / 255, 61 / 255)
blue = (77 / 255, 133 / 255, 189 / 255)
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("Working directory set to:", os.getcwd())
def LoadExpCIT(ExpName):
    crossname = ExpName
    crossing_data = pd.read_csv(crossname)
    df_exp = pd.DataFrame(crossing_data)

    mask6_2_0 = df_exp['trial_id'] == 6
    mask6_4_0 = df_exp['trial_id'] == 4
    mask6_6_0 = df_exp['trial_id'] == 8
    mask13_2_0 = df_exp['trial_id'] == 5
    mask13_4_0 = df_exp['trial_id'] == 3
    mask13_6_0 = df_exp['trial_id'] == 7

    mask13_4_4 = df_exp['trial_id'] == 9
    mask13_2_4 = df_exp['trial_id'] == 10
    mask13_6_4 = df_exp['trial_id'] == 11
    mask6_4_4 = df_exp['trial_id'] == 12
    mask6_2_4 = df_exp['trial_id'] == 13
    mask6_6_4 = df_exp['trial_id'] == 14

    mask13_2_8 = df_exp['trial_id'] == 15
    mask13_4_8 = df_exp['trial_id'] == 16

    start6_2_0 = df_exp[mask6_2_0]['cross_time'].tolist()
    start6_2_0.sort()
    start6_4_0 = df_exp[mask6_4_0]['cross_time'].tolist()
    start6_4_0.sort()
    start6_6_0 = df_exp[mask6_6_0]['cross_time'].tolist()
    start6_6_0.sort()
    start13_2_0 = df_exp[mask13_2_0]['cross_time'].tolist()
    start13_2_0.sort()
    start13_4_0 = df_exp[mask13_4_0]['cross_time'].tolist()
    start13_4_0.sort()
    start13_6_0 = df_exp[mask13_6_0]['cross_time'].tolist()
    start13_6_0.sort()
    start13_4_4 = df_exp[mask13_4_4]['cross_time'].tolist()
    start13_4_4.sort()
    start13_2_4 = df_exp[mask13_2_4]['cross_time'].tolist()
    start13_2_4.sort()
    start13_6_4 = df_exp[mask13_6_4]['cross_time'].tolist()
    start13_6_4.sort()
    start6_4_4 = df_exp[mask6_4_4]['cross_time'].tolist()
    start6_4_4.sort()
    start6_2_4 = df_exp[mask6_2_4]['cross_time'].tolist()
    start6_2_4.sort()
    start6_6_4 = df_exp[mask6_6_4]['cross_time'].tolist()
    start6_6_4.sort()
    start13_2_8 = df_exp[mask13_2_8]['cross_time'].tolist()
    start13_2_8.sort()
    start13_4_8 = df_exp[mask13_4_8]['cross_time'].tolist()
    start13_4_8.sort()

    x6_2_0_exp = [0]
    y6_2_0_exp = [0]
    for i in range(len(start6_2_0)):
        x6_2_0_exp.append(start6_2_0[i])
        y6_2_0_exp.append((i + 1) / len(start6_2_0))
    x6_2_0_exp.append(15)
    y6_2_0_exp.append(1)

    x6_4_0_exp = [0]
    y6_4_0_exp = [0]
    for i in range(len(start6_4_0)):
        x6_4_0_exp.append(start6_4_0[i])
        y6_4_0_exp.append((i + 1) / len(start6_4_0))
    x6_4_0_exp.append(15)
    y6_4_0_exp.append(1)

    x6_6_0_exp = [0]
    y6_6_0_exp = [0]
    for i in range(len(start6_6_0)):
        x6_6_0_exp.append(start6_6_0[i])
        y6_6_0_exp.append((i + 1) / len(start6_6_0))
    x6_6_0_exp.append(15)
    y6_6_0_exp.append(1)

    x13_2_0_exp = [0]
    y13_2_0_exp = [0]
    for i in range(len(start13_2_0)):
        x13_2_0_exp.append(start13_2_0[i])
        y13_2_0_exp.append((i + 1) / len(start13_2_0))
    x13_2_0_exp.append(15)
    y13_2_0_exp.append(1)

    x13_4_0_exp = [0]
    y13_4_0_exp = [0]
    for i in range(len(start13_4_0)):
        x13_4_0_exp.append(start13_4_0[i])
        y13_4_0_exp.append((i + 1) / len(start13_4_0))
    x13_4_0_exp.append(15)
    y13_4_0_exp.append(1)

    x13_6_0_exp = [0]
    y13_6_0_exp = [0]
    for i in range(len(start13_6_0)):
        x13_6_0_exp.append(start13_6_0[i])
        y13_6_0_exp.append((i + 1) / len(start13_6_0))
    x13_6_0_exp.append(15)
    y13_6_0_exp.append(1)

    x13_4_4_exp = [0]
    y13_4_4_exp = [0]
    for i in range(len(start13_4_4)):
        x13_4_4_exp.append(start13_4_4[i])
        y13_4_4_exp.append((i + 1) / len(start13_4_4))
    x13_4_4_exp.append(15)
    y13_4_4_exp.append(1)

    x13_2_4_exp = [0]
    y13_2_4_exp = [0]
    for i in range(len(start13_2_4)):
        x13_2_4_exp.append(start13_2_4[i])
        y13_2_4_exp.append((i + 1) / len(start13_2_4))
    x13_2_4_exp.append(15)
    y13_2_4_exp.append(1)

    x13_6_4_exp = [0]
    y13_6_4_exp = [0]
    for i in range(len(start13_6_4)):
        x13_6_4_exp.append(start13_6_4[i])
        y13_6_4_exp.append((i + 1) / len(start13_6_4))
    x13_6_4_exp.append(15)
    y13_6_4_exp.append(1)

    x6_4_4_exp = [0]
    y6_4_4_exp = [0]
    for i in range(len(start6_4_4)):
        x6_4_4_exp.append(start6_4_4[i])
        y6_4_4_exp.append((i + 1) / len(start6_4_4))
    x6_4_4_exp.append(15)
    y6_4_4_exp.append(1)

    x6_2_4_exp = [0]
    y6_2_4_exp = [0]
    for i in range(len(start6_2_4)):
        x6_2_4_exp.append(start6_2_4[i])
        y6_2_4_exp.append((i + 1) / len(start6_2_4))
    x6_2_4_exp.append(15)
    y6_2_4_exp.append(1)

    x6_6_4_exp = [0]
    y6_6_4_exp = [0]
    for i in range(len(start6_6_4)):
        x6_6_4_exp.append(start6_6_4[i])
        y6_6_4_exp.append((i + 1) / len(start6_6_4))
    x6_6_4_exp.append(15)
    y6_6_4_exp.append(1)

    x13_2_8_exp = [0]
    y13_2_8_exp = [0]
    for i in range(len(start13_2_8)):
        x13_2_8_exp.append(start13_2_8[i])
        y13_2_8_exp.append((i + 1) / len(start13_2_8))
    x13_2_8_exp.append(15)
    y13_2_8_exp.append(1)

    x13_4_8_exp = [0]
    y13_4_8_exp = [0]
    for i in range(len(start13_4_8)):
        x13_4_8_exp.append(start13_4_8[i])
        y13_4_8_exp.append((i + 1) / len(start13_4_8))
    x13_4_8_exp.append(15)
    y13_4_8_exp.append(1)

    return x6_2_0_exp, x6_4_0_exp, x6_6_0_exp, x13_2_0_exp, x13_4_0_exp, x13_6_0_exp,\
           y6_2_0_exp, y6_4_0_exp, y6_6_0_exp, y13_2_0_exp, y13_4_0_exp, y13_6_0_exp, \
           x13_4_4_exp,x13_2_4_exp, x13_6_4_exp,x6_4_4_exp,x6_2_4_exp,x6_6_4_exp, x13_2_8_exp, x13_4_8_exp,\
           y13_4_4_exp,y13_2_4_exp, y13_6_4_exp,y6_4_4_exp,y6_2_4_exp,y6_6_4_exp, y13_2_8_exp, y13_4_8_exp



def CIT(df):

    # df = df.dropna(axis=0)
    df = df[df['score'] == 1]
    # print(df)

    gap10 = df['time_gap'] == 1
    gap15 = df['time_gap'] == 1.5
    gap23 = df['time_gap'] == 2.3
    gap35 = df['time_gap'] == 3.5
    gap46 = df['time_gap'] == 4.6
    gap55 = df['time_gap'] == 5.5
    gap69 = df['time_gap'] == 6.9
    #
    # gap3 = df['time_gap'] == 2.3
    # gap4 = df['time_gap'] == 4.6
    # gap5 = df['time_gap'] == 6.9
    speed25 = df['speed'] == 6.94
    speed30 = df['speed'] == 13.89
    speed35 = df['speed'] == 15.65
    acc0 = df['acceleration'] == 0
    acc1 = df['acceleration'] == 2.02
    acc2 = df['acceleration'] == 3.47
    acc3 = df['acceleration'] == 4.05
    acc4 = df['acceleration'] == 0.87
    acc5 = df['acceleration'] == 1.62
    acc6 = df['acceleration'] == 1.73
    acc7 = df['acceleration'] == 0.55
    acc8 = df['acceleration'] == 1.06

    # print(df['start_time'][speed25][gap3].tolist())
    start6_2 = df['start_time'][speed25][gap23][acc0].tolist()
    start6_2.sort()
    start6_4 = df['start_time'][speed25][gap46][acc0].tolist()
    start6_4.sort()
    start6_6 = df['start_time'][speed25][gap69][acc0].tolist()
    start6_6.sort()
    start13_2 = df['start_time'][speed30][gap23][acc0].tolist()
    start13_2.sort()
    start13_4 = df['start_time'][speed30][gap46][acc0].tolist()
    start13_4.sort()
    start13_6 = df['start_time'][speed30][gap69][acc0].tolist()
    start13_6.sort()

    start6_2_4 = df['start_time'][speed25][gap23][acc1].tolist()
    start6_2_4.sort()
    start13_2_4 = df['start_time'][speed30][gap23][acc2].tolist()
    start13_2_4.sort()
    start13_2_8 = df['start_time'][speed30][gap23][acc3].tolist()
    start13_2_8.sort()
    start6_4_4 = df['start_time'][speed25][gap46][acc4].tolist()
    start6_4_4.sort()
    start13_4_4 = df['start_time'][speed30][gap46][acc5].tolist()
    start13_4_4.sort()
    start13_4_8 = df['start_time'][speed30][gap46][acc6].tolist()
    start13_4_8.sort()
    start6_6_4 = df['start_time'][speed25][gap69][acc7].tolist()
    start6_6_4.sort()
    start13_6_4 = df['start_time'][speed30][gap69][acc8].tolist()
    start13_6_4.sort()

    x6_2 = [0]
    y6_2 = [0]
    for i in range(len(start6_2)):
        x6_2.append(start6_2[i])
        y6_2.append((i + 1) / len(start6_2))
    x6_2.append(15)
    y6_2.append(1)

    x6_4 = [0]
    y6_4 = [0]
    for i in range(len(start6_4)):
        x6_4.append(start6_4[i])
        y6_4.append((i + 1) / len(start6_4))
    x6_4.append(15)
    y6_4.append(1)

    x6_6 = [0]
    y6_6 = [0]
    for i in range(len(start6_6)):
        x6_6.append(start6_6[i])
        y6_6.append((i + 1) / len(start6_6))
    x6_6.append(15)
    y6_6.append(1)

    x13_2 = [0]
    y13_2 = [0]
    for i in range(len(start13_2)):
        x13_2.append(start13_2[i])
        y13_2.append((i + 1) / len(start13_2))
    x13_2.append(15)
    y13_2.append(1)

    x13_4 = [0]
    y13_4 = [0]
    for i in range(len(start13_4)):
        x13_4.append(start13_4[i])
        y13_4.append((i + 1) / len(start13_4))
    x13_4.append(15)
    y13_4.append(1)

    x13_6 = [0]
    y13_6 = [0]
    for i in range(len(start13_6)):
        x13_6.append(start13_6[i])
        y13_6.append((i + 1) / len(start13_6))
    x13_6.append(15)
    y13_6.append(1)

    x6_2_4 = [0]
    y6_2_4 = [0]
    for i in range(len(start6_2_4)):
        x6_2_4.append(start6_2_4[i])
        y6_2_4.append((i + 1) / len(start6_2_4))
    x6_2_4.append(15)
    y6_2_4.append(1)

    x13_2_4 = [0]
    y13_2_4 = [0]
    for i in range(len(start13_2_4)):
        x13_2_4.append(start13_2_4[i])
        y13_2_4.append((i + 1) / len(start13_2_4))
    x13_2_4.append(15)
    y13_2_4.append(1)

    x13_2_8 = [0]
    y13_2_8 = [0]
    for i in range(len(start13_2_8)):
        x13_2_8.append(start13_2_8[i])
        y13_2_8.append((i + 1) / len(start13_2_8))
    x13_2_8.append(15)
    y13_2_8.append(1)

    x6_4_4 = [0]
    y6_4_4 = [0]
    for i in range(len(start6_4_4)):
        x6_4_4.append(start6_4_4[i])
        y6_4_4.append((i + 1) / len(start6_4_4))
    x6_4_4.append(15)
    y6_4_4.append(1)

    x13_4_4 = [0]
    y13_4_4 = [0]
    for i in range(len(start13_4_4)):
        x13_4_4.append(start13_4_4[i])
        y13_4_4.append((i + 1) / len(start13_4_4))
    x13_4_4.append(15)
    y13_4_4.append(1)

    x13_4_8 = [0]
    y13_4_8 = [0]
    for i in range(len(start13_4_8)):
        x13_4_8.append(start13_4_8[i])
        y13_4_8.append((i + 1) / len(start13_4_8))
    x13_4_8.append(15)
    y13_4_8.append(1)

    x6_6_4 = [0]
    y6_6_4 = [0]
    for i in range(len(start6_6_4)):
        x6_6_4.append(start6_6_4[i])
        y6_6_4.append((i + 1) / len(start6_6_4))
    x6_6_4.append(15)
    y6_6_4.append(1)

    x13_6_4 = [0]
    y13_6_4 = [0]
    for i in range(len(start13_6_4)):
        x13_6_4.append(start13_6_4[i])
        y13_6_4.append((i + 1) / len(start13_6_4))
    x13_6_4.append(15)
    y13_6_4.append(1)

    return x6_2, y6_2,x13_2, y13_2,x6_4, y6_4,x13_4, y13_4,x6_6, y6_6,x13_6, y13_6,\
           x6_2_4, y6_2_4,x13_2_4, y13_2_4,x13_2_8, y13_2_8, x6_4_4, y6_4_4,x13_4_4, \
           y13_4_4,x13_4_8, y13_4_8,x6_6_4, y6_6_4,x13_6_4, y13_6_4


def plotLearning():

    path = "./Exp_data"
    crossname = path+'/d2p_cross_times_uk.csv'

    x6_2_0_exp, x6_4_0_exp, x6_6_0_exp, x13_2_0_exp, x13_4_0_exp, x13_6_0_exp,y6_2_0_exp, y6_4_0_exp, y6_6_0_exp, y13_2_0_exp, y13_4_0_exp, y13_6_0_exp, \
               x13_4_4_exp,x13_2_4_exp, x13_6_4_exp,x6_4_4_exp,x6_2_4_exp,x6_6_4_exp, x13_2_8_exp, x13_4_8_exp,\
               y13_4_4_exp,y13_2_4_exp, y13_6_4_exp,y6_4_4_exp,y6_2_4_exp,y6_6_4_exp, y13_2_8_exp, y13_4_8_exp= LoadExpCIT(crossname)
    Exp2 =x6_2_0_exp + x13_2_0_exp
    Exp4 =x6_4_0_exp + x13_4_0_exp
    Exp6 =x6_6_0_exp + x13_6_0_exp

    rightlabel_font = 24
    leftlabel_font = 24
    title_font = 24
    text_font = 20
    tick_size = 20
    legend_size = 20
    linewidth = 3
    alpha = 0.8
    fig = plt.figure(figsize=(16, 16))
    gs = GridSpec(5, 9, figure=fig)

    # Subplots for CIT Plot
    ax1 = fig.add_subplot(gs[0, 0:3])
    ax2 = fig.add_subplot(gs[0, 3:6])
    ax3 = fig.add_subplot(gs[0, 6:9])
    ax4 = fig.add_subplot(gs[1, 0:3])
    ax5 = fig.add_subplot(gs[1, 3:6])
    ax6 = fig.add_subplot(gs[1, 6:9])
    ax7 = fig.add_subplot(gs[2, 0:3])
    ax8 = fig.add_subplot(gs[2, 3:6])
    ax9 = fig.add_subplot(gs[2, 6:9])
    ax10 = fig.add_subplot(gs[3, 0:3])
    ax11 = fig.add_subplot(gs[3, 3:6])
    ax12 = fig.add_subplot(gs[3, 6:9])
    ax13 = fig.add_subplot(gs[4, 0:3])
    ax14 = fig.add_subplot(gs[4, 3:6])
    ax15 = fig.add_subplot(gs[4, 6:9])


    x2 = [2.3, 2.3]
    x4 = [4.6, 4.6]
    x6 = [6.9, 6.9]
    y = [0, 1.1]

    ax1.plot(x6_2_0_exp, y6_2_0_exp,alpha=alpha,color=blue,linewidth = linewidth)
    ax1.plot(x13_2_0_exp, y13_2_0_exp, alpha=alpha, color=orange,linewidth = linewidth)
    ax1.plot(x2, y, alpha=0.7, color='k',linewidth = 2,linestyle='--')

    ax2.plot(x6_4_0_exp, y6_4_0_exp,alpha=alpha, color=blue,linewidth = linewidth)
    ax2.plot(x13_4_0_exp, y13_4_0_exp, alpha=alpha,color=orange,linewidth = linewidth)
    ax2.plot(x4, y, alpha=0.7, color='k',linewidth = 2,linestyle='--')

    ax3.plot(x6_6_0_exp, y6_6_0_exp, alpha=alpha, color=blue, label='6.9 m/s',linewidth = linewidth)
    ax3.plot(x13_6_0_exp, y13_6_0_exp, alpha=alpha, color=orange, label='13.9 m/s',linewidth = linewidth)
    ax3.plot(x6, y, alpha=0.7, color='k',linewidth = 2,linestyle='--')
    ax3.legend(prop={'size': legend_size}, loc='lower right',bbox_to_anchor=(1.05,-0.044), framealpha=0.5)

    model_num = 'IO'
    input = 5
    num = None
    csv_dir = f'../Sim_Data/Sim_data_{model_num}_Dec'
    df_all = pd.DataFrame()
    csvname = f'Input_{input}_Test{num}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df_all = pd.read_csv(csv_file)
    x6_2, y6_2, x13_2, y13_2, x6_4, y6_4, x13_4, y13_4, x6_6, y6_6, x13_6, y13_6, \
    x6_2_4, y6_2_4, x13_2_4, y13_2_4, x13_2_8, y13_2_8, x6_4_4, y6_4_4, x13_4_4, \
    y13_4_4, x13_4_8, y13_4_8, x6_6_4, y6_6_4, x13_6_4, y13_6_4 = CIT(df_all)

    IO2 =x6_2 + x13_2
    IO4 =x6_4 + x13_4
    IO6 =x6_6 + x13_6
    ks_statistic2, ks_p_value = ks_2samp(Exp2, IO2)
    ks_statistic4, ks_p_value = ks_2samp(Exp4, IO4)
    ks_statistic6, ks_p_value = ks_2samp(Exp6, IO6)

    ax4.plot(x6_2, y6_2, alpha=alpha, color=blue, linewidth=linewidth)
    ax4.plot(x13_2, y13_2, alpha=alpha, color=orange, linewidth=linewidth)
    # ax4.plot(x2, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax5.plot(x6_4, y6_4, alpha=alpha, color=blue, linewidth=linewidth)
    ax5.plot(x13_4, y13_4, alpha=alpha, color=orange, linewidth=linewidth)
    # ax5.plot(x4, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax6.plot(x6_6, y6_6, alpha=alpha, color=blue, label='Model 6.9 m/s', linewidth=linewidth)
    ax6.plot(x13_6, y13_6, alpha=alpha, color=orange, label='Model 13.9 m/s', linewidth=linewidth)
    # ax6.plot(x6, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax4.text(6.0, 0.1, f'KS Statistic: {ks_statistic2:.2f}', color='black', fontsize=text_font)
    ax5.text(6.0, 0.1, f'KS Statistic: {ks_statistic4:.2f}', color='black', fontsize=text_font)
    ax6.text(6.0, 0.1, f'KS Statistic: {ks_statistic6:.2f}', color='black', fontsize=text_font)

    model_num = 0
    input = 8
    sigma_file = f'../IT/ID_IT/ID_IT_{model_num}_Delay_Dec.csv'
    df_IT = pd.read_csv(sigma_file)
    IT_list = df_IT['Inverse_TTA_Coef'].round(3).tolist()

    df_all = pd.DataFrame()
    print(len(df_IT))
    csv_dir = f'../Sim_Data/DQN_IT_Input/Sim_data_{model_num}_Delay_Dec'
    for i in range(len(df_IT)):
        IT = IT_list[i]
        k = None
        csvname = f'InverseTTA_{IT}_Input_{input}_Test{k}.csv'
        # csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_<built-in function input>_Test{k}.csv'
        csv_file = os.path.join(csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df_all = pd.concat([df_all, df], ignore_index=True)
        print(f'InverseTTA:{IT};csvname:{csv_file}')
    x6_2, y6_2, x13_2, y13_2, x6_4, y6_4, x13_4, y13_4, x6_6, y6_6, x13_6, y13_6, \
    x6_2_4, y6_2_4, x13_2_4, y13_2_4, x13_2_8, y13_2_8, x6_4_4, y6_4_4, x13_4_4, \
    y13_4_4, x13_4_8, y13_4_8, x6_6_4, y6_6_4, x13_6_4, y13_6_4 = CIT(df_all)
    IM2 =x6_2 + x13_2
    IM4 =x6_4 + x13_4
    IM6 =x6_6 + x13_6
    ks_statistic2, ks_p_value = ks_2samp(Exp2, IM2)
    ks_statistic4, ks_p_value = ks_2samp(Exp4, IM4)
    ks_statistic6, ks_p_value = ks_2samp(Exp6, IM6)


    ax7.plot(x6_2, y6_2, alpha=alpha, color=blue, linewidth=linewidth)
    ax7.plot(x13_2, y13_2, alpha=alpha, color=orange, linewidth=linewidth)
    # ax7.plot(x2, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax8.plot(x6_4, y6_4, alpha=alpha, color=blue, linewidth=linewidth)
    ax8.plot(x13_4, y13_4, alpha=alpha, color=orange, linewidth=linewidth)
    # ax8.plot(x4, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax9.plot(x6_6, y6_6, alpha=alpha, color=blue, label='Model 6.9 m/s', linewidth=linewidth)
    ax9.plot(x13_6, y13_6, alpha=alpha, color=orange, label='Model 13.9 m/s', linewidth=linewidth)
    # ax9.plot(x6, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax7.text(6.0, 0.1, f'KS Statistic: {ks_statistic2:.2f}', color='black', fontsize=text_font)
    ax8.text(6.0, 0.1, f'KS Statistic: {ks_statistic4:.2f}', color='black', fontsize=text_font)
    ax9.text(6.0, 0.1, f'KS Statistic: {ks_statistic6:.2f}', color='black', fontsize=text_font)

    model_num = 0
    input = 10
    sigma_file = f'../Sigma/ID_Sigma/ID_Sigma_{model_num}_Dec.csv'
    df_sigma = pd.read_csv(sigma_file)
    sigma_list = df_sigma['Sigma'].round(3).tolist()
    df_all = pd.DataFrame()
    print(len(df_sigma))
    csv_dir = f'../Sim_Data/DQN_Sigma_Input/Sim_data_{model_num}_Delay_Dec'
    for i in range(len(df_sigma)):
        sigma = sigma_list[i]
        k = None
        csvname = f'Sigma_{sigma}_Input_{input}_Test{k}.csv'
        csv_file = os.path.join(csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df_all = pd.concat([df_all, df], ignore_index=True)
        print(f'sigma:{sigma};csvname:{csv_file}')
    x6_2, y6_2, x13_2, y13_2, x6_4, y6_4, x13_4, y13_4, x6_6, y6_6, x13_6, y13_6, \
        x6_2_4, y6_2_4, x13_2_4, y13_2_4, x13_2_8, y13_2_8, x6_4_4, y6_4_4, x13_4_4, \
        y13_4_4, x13_4_8, y13_4_8, x6_6_4, y6_6_4, x13_6_4, y13_6_4 = CIT(df_all)

    VM2 =x6_2 + x13_2
    VM4 =x6_4 + x13_4
    VM6 =x6_6 + x13_6
    ks_statistic2, ks_p_value = ks_2samp(Exp2, VM2)
    ks_statistic4, ks_p_value = ks_2samp(Exp4, VM4)
    ks_statistic6, ks_p_value = ks_2samp(Exp6, VM6)


    ax10.plot(x6_2, y6_2, alpha=alpha, color=blue, linewidth=linewidth)
    ax10.plot(x13_2, y13_2, alpha=alpha, color=orange, linewidth=linewidth)
    # ax10.plot(x2, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax11.plot(x6_4, y6_4, alpha=alpha, color=blue, linewidth=linewidth)
    ax11.plot(x13_4, y13_4, alpha=alpha, color=orange, linewidth=linewidth)
    # ax11.plot(x4, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax12.plot(x6_6, y6_6, alpha=alpha, color=blue, label='Model 6.9 m/s', linewidth=linewidth)
    ax12.plot(x13_6, y13_6, alpha=alpha, color=orange, label='Model 13.9 m/s', linewidth=linewidth)
    # ax12.plot(x6, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax10.text(6.0, 0.1, f'KS Statistic: {ks_statistic2:.2f}', color='black', fontsize=text_font)
    ax11.text(6.0, 0.1, f'KS Statistic: {ks_statistic4:.2f}', color='black', fontsize=text_font)
    ax12.text(6.0, 0.1, f'KS Statistic: {ks_statistic6:.2f}', color='black', fontsize=text_font)


    model_num = 0
    input = 11
    sigma_file = f'../Sigma_IT/ID_Sigma_IT/ID_Sigma_IT_{model_num}_Delay_Dec.csv'
    df_sigma = pd.read_csv(sigma_file)
    sigma_list = df_sigma['Sigma'].round(3).tolist()
    InverseTTA_Coef_list = df_sigma['InverseTTA_Coef'].round(3).tolist()

    df_all = pd.DataFrame()
    print(len(df_sigma))
    csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
    for i in range(len(df_sigma)):
        sigma = sigma_list[i]
        Inverse_TTA_Coef = InverseTTA_Coef_list[i]
        k = None
        csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_{input}_Test{k}.csv'
        # csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_<built-in function input>_Test{k}.csv'
        csv_file = os.path.join(csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df_all = pd.concat([df_all, df], ignore_index=True)
        print(f'sigma:{sigma};csvname:{csv_file}')
    x6_2, y6_2, x13_2, y13_2, x6_4, y6_4, x13_4, y13_4, x6_6, y6_6, x13_6, y13_6, \
        x6_2_4, y6_2_4, x13_2_4, y13_2_4, x13_2_8, y13_2_8, x6_4_4, y6_4_4, x13_4_4, \
        y13_4_4, x13_4_8, y13_4_8, x6_6_4, y6_6_4, x13_6_4, y13_6_4 = CIT(df_all)
    VIM2 =x6_2 + x13_2
    VIM4 =x6_4 + x13_4
    VIM6 =x6_6 + x13_6
    ks_statistic2, ks_p_value = ks_2samp(Exp2, VIM2)
    ks_statistic4, ks_p_value = ks_2samp(Exp4, VIM4)
    ks_statistic6, ks_p_value = ks_2samp(Exp6, VIM6)


    ax13.plot(x6_2, y6_2, alpha=alpha, color=blue, linewidth=linewidth)
    ax13.plot(x13_2, y13_2, alpha=alpha, color=orange, linewidth=linewidth)
    # ax13.plot(x2, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax14.plot(x6_4, y6_4, alpha=alpha, color=blue, linewidth=linewidth)
    ax14.plot(x13_4, y13_4, alpha=alpha, color=orange, linewidth=linewidth)
    # ax14.plot(x4, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax15.plot(x6_6, y6_6, alpha=alpha, color=blue, label='6.9 m/s', linewidth=linewidth)
    ax15.plot(x13_6, y13_6, alpha=alpha, color=orange, label='13.9 m/s', linewidth=linewidth)
    # ax15.plot(x6, y, alpha=alpha, color='grey', linewidth=linewidth)
    ax13.text(6.0, 0.1, f'KS Statistic: {ks_statistic2:.2f}', color='black', fontsize=text_font)
    ax14.text(6.0, 0.1, f'KS Statistic: {ks_statistic4:.2f}', color='black', fontsize=text_font)
    ax15.text(6.0, 0.1, f'KS Statistic: {ks_statistic6:.2f}', color='black', fontsize=text_font)

    collision_num = []
    collision_rates = []
    for i in range(len(df['collision'])):
        if df.iloc[i]['collision'] == 1:
            collision_num.append(1)
        else:
            pass

        collision_rate = len(collision_num)/(i+1)
        collision_rates.append(collision_rate)

    ax1.set_title('Initial TTA: 2.3 s', fontsize=title_font)
    ax2.set_title('Initial TTA: 4.6 s', fontsize=title_font)
    ax3.set_title('Initial TTA: 6.9 s', fontsize=title_font)
    ax1.set_xlim(0, 15)
    ax1.set_ylim(0, 1.1)
    ax2.set_xlim(0, 15)
    ax2.set_ylim(0, 1.1)
    ax3.set_xlim(0, 15)
    ax3.set_ylim(0, 1.1)
    ax4.set_xlim(0, 15)
    ax4.set_ylim(0, 1.1)
    ax5.set_xlim(0, 15)
    ax5.set_ylim(0, 1.1)
    ax6.set_xlim(0, 15)
    ax6.set_ylim(0, 1.1)
    ax7.set_xlim(0, 15)
    ax7.set_ylim(0, 1.1)
    ax8.set_xlim(0, 15)
    ax8.set_ylim(0, 1.1)
    ax9.set_xlim(0, 15)
    ax9.set_ylim(0, 1.1)
    ax10.set_xlim(0, 15)
    ax10.set_ylim(0, 1.1)
    ax11.set_xlim(0, 15)
    ax11.set_ylim(0, 1.1)
    ax12.set_xlim(0, 15)
    ax12.set_ylim(0, 1.1)
    ax13.set_xlim(0, 15)
    ax13.set_ylim(0, 1.1)
    ax14.set_xlim(0, 15)
    ax14.set_ylim(0, 1.1)
    ax15.set_xlim(0, 15)
    ax15.set_ylim(0, 1.1)


    ax1.xaxis.set_ticklabels([])
    ax2.yaxis.set_ticklabels([])
    ax2.xaxis.set_ticklabels([])
    ax3.yaxis.set_ticklabels([])
    ax3.xaxis.set_ticklabels([])
    ax4.xaxis.set_ticklabels([])
    ax5.yaxis.set_ticklabels([])
    ax5.xaxis.set_ticklabels([])
    ax6.yaxis.set_ticklabels([])
    ax6.xaxis.set_ticklabels([])
    ax7.xaxis.set_ticklabels([])
    ax8.xaxis.set_ticklabels([])
    ax8.yaxis.set_ticklabels([])
    ax9.yaxis.set_ticklabels([])
    ax9.xaxis.set_ticklabels([])
    ax10.xaxis.set_ticklabels([])

    ax11.yaxis.set_ticklabels([])
    ax11.xaxis.set_ticklabels([])

    ax12.yaxis.set_ticklabels([])
    ax12.xaxis.set_ticklabels([])
    # ax13.xaxis.set_ticklabels([])
    ax14.yaxis.set_ticklabels([])
    # ax14.xaxis.set_ticklabels([])
    ax15.yaxis.set_ticklabels([])
    ax1.yaxis.set_tick_params(labelsize=tick_size)
    ax4.yaxis.set_tick_params(labelsize=tick_size)
    ax7.yaxis.set_tick_params(labelsize=tick_size)
    ax10.yaxis.set_tick_params(labelsize=tick_size)
    ax13.xaxis.set_tick_params(labelsize=tick_size)
    ax13.yaxis.set_tick_params(labelsize=tick_size)
    ax14.xaxis.set_tick_params(labelsize=tick_size)
    ax15.xaxis.set_tick_params(labelsize=tick_size)
    ax13.set_xticks([ 0,2, 4, 6, 8, 10,12,14])
    ax14.set_xticks([ 0,2, 4, 6, 8, 10,12,14])
    ax15.set_xticks([ 0,2, 4, 6, 8, 10,12,14])

    ax7.set_ylabel('Cumulative probability', fontsize=leftlabel_font)
    # ax10.yaxis.set_label_coords(-0.15, 1)
    ax3.set_ylabel('Human data', fontsize=rightlabel_font)
    ax3.yaxis.set_label_position("right")

    ax6.set_ylabel('BM', fontsize=rightlabel_font)
    ax6.yaxis.set_label_position("right")
    ax9.set_ylabel('LM', fontsize=rightlabel_font)
    ax9.yaxis.set_label_position("right")
    ax12.set_ylabel('VM', fontsize=rightlabel_font)
    ax12.yaxis.set_label_position("right")
    ax15.set_ylabel('VLM', fontsize=rightlabel_font)
    ax15.yaxis.set_label_position("right")

    ax14.set_xlabel("Time in trial (s)", size=title_font, labelpad=10)


    combined_plotname = f'CIT_ConstantKS.png'

    combined_plot = os.path.join(plot_dir, combined_plotname)
    # plt.tight_layout()

    plt.savefig(combined_plot, dpi=300, bbox_inches='tight')
    plt.show()

plot_dir = 'Plot'
os.makedirs(plot_dir, exist_ok=True)

if __name__ == '__main__':
    plotLearning()