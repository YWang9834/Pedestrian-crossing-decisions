import matplotlib.pyplot as plt
import numpy as np
import gym
from matplotlib.gridspec import GridSpec
import pandas as pd
import os
import seaborn as sns
MultipleFiles = False
Constant = False
model_num = 0
input = 11
import matplotlib.pyplot as plt
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("Working directory set to:", os.getcwd())
if Constant:
    sigma_file = f'../Sigma_IT/ID_Sigma_IT/ID_Sigma_IT_{model_num}_Delay.csv'
else:
    sigma_file = f'../Sigma_IT/ID_Sigma_IT/ID_Sigma_IT_{model_num}_Delay_Dec.csv'
df_sigma = pd.read_csv(sigma_file)
sigma_list = df_sigma['Sigma'].round(3).tolist()
InverseTTA_Coef_list = df_sigma['InverseTTA_Coef'].round(3).tolist()
print(sigma_list)
print(InverseTTA_Coef_list)
# Function to jitter the position of duplicate points slightly
def jitter(values, jitter_amount):
    # return values + np.random.uniform(-jitter_amount, jitter_amount, len(values))

    return values -jitter_amount

df_sigma = pd.read_csv(sigma_file)
df_sigma['Sigma'] = df_sigma['Sigma'].round(3)
df_sigma['InverseTTA_Coef'] = df_sigma['InverseTTA_Coef'].round(3)

# Create a boolean mask for duplicates
duplicates_mask = df_sigma.duplicated(subset=['Sigma', 'InverseTTA_Coef'], keep=False)

# Separate duplicates and non-duplicates
df_duplicates = df_sigma[duplicates_mask]
df_non_duplicates = df_sigma[~duplicates_mask]

# Get counts of duplicates
df_duplicates.groupby(['Sigma', 'InverseTTA_Coef'])
dup_counts = df_duplicates.groupby(['Sigma', 'InverseTTA_Coef']).size().reset_index(name='Counts')

# dup_counts = df_duplicates.groupby(['Sigma', 'InverseTTA_Coef']).size().reset_index(name='Counts').astype(int)
# print(df_duplicates)
print(dup_counts)
# Plotting
plt.style.use('seaborn-v0_8')

plt.figure(figsize=(6, 6))
rightlabel_font = 24
leftlabel_font = 26
title_font = 24
linewidth = 1.8
label_text_size  = 16
legend_size = 17
tick_size = 20
alpha = 0.8




# Plot non-duplicates
# plt.scatter(df_non_duplicates['Sigma'], df_non_duplicates['InverseTTA_Coef'], label='Unique points')
# # plt.scatter(df_duplicates['Sigma'], df_duplicates['InverseTTA_Coef'], label='Unique points', color='red')
#
# # Plot duplicates
# for i, row in dup_counts.iterrows():
#     plt.scatter(row['Sigma'], row['InverseTTA_Coef'], color='red', label='Duplicate points' if i == 0 else "")
#     # print(row['Sigma'])
#     # print(row['InverseTTA_Coef'])
#     plt.text(row['Sigma'], row['InverseTTA_Coef']+2, f'{row["Counts"].astype(int)}', color='black', ha='right', fontsize=label_text_size)

# Plot non-duplicates
plt.scatter(df_non_duplicates['Sigma'], df_non_duplicates['InverseTTA_Coef'], alpha=alpha, color = 'cornflowerblue')

# Apply jitter to the x-coordinate of duplicates and plot
jitter_amount = 0.01  # Adjust this value as needed to get the desired visual effect
df_duplicates['Sigma_jittered_1'] = jitter(df_duplicates['Sigma'], jitter_amount=jitter_amount)
jitter_amount = -0.01  # Adjust this value as needed to get the desired visual effect

df_duplicates['Sigma_jittered_2'] = jitter(df_duplicates['Sigma'], jitter_amount=jitter_amount)

# print(df_duplicates['Sigma_jittered'])
plt.scatter(df_duplicates['Sigma_jittered_1'], df_duplicates['InverseTTA_Coef'], alpha=alpha, color = 'cornflowerblue')
plt.scatter(df_duplicates['Sigma_jittered_2'], df_duplicates['InverseTTA_Coef'], alpha=alpha, color = 'cornflowerblue')

# plt.scatter(df_duplicates['Sigma'], df_duplicates['InverseTTA_Coef'], alpha=alpha, color = 'cornflowerblue')

plt.xlabel(r'$\sigma_{\text{v}}$', fontsize=leftlabel_font)
plt.ylabel(r'$c$', fontsize=leftlabel_font)


plt.xlim(-0.05,1.1)
plt.ylim(-5,110)
plt.xticks(fontsize=tick_size)
plt.yticks(fontsize=tick_size)
plt.grid(True)


# Ensure that the legend only shows one entry for "Duplicate points"
handles, labels = plt.gca().get_legend_handles_labels()
by_label = dict(zip(labels, handles))
# plt.legend(by_label.values(), by_label.keys(), prop={'size': legend_size}, frameon=True, edgecolor='black', facecolor='white', framealpha=1)


# plt.legend(prop={'size': legend_size}, frameon=True, edgecolor='black', facecolor='white', framealpha=1)

plot_dir = 'Plot'
name = f'ParametersMulti.png'

PlotName = os.path.join(plot_dir, name)
plt.savefig(PlotName, dpi=300, bbox_inches='tight')
plt.show()







