import matplotlib.pyplot as plt
import numpy as np
import gym
from matplotlib.gridspec import GridSpec
import pandas as pd
import os
import seaborn as sns
MultipleFiles = False
SeperatePlot = False
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("Working directory set to:", os.getcwd())
model_num = 'IO'
input = 5
num = None
csv_dir = f'../Sim_Data/Sim_data_{model_num}_Dec'
df_IO = pd.DataFrame()
csvname = f'Input_{input}_Test{num}.csv'
csv_file = os.path.join(csv_dir, csvname)
df_IO = pd.read_csv(csv_file)

model_num = 0
input = 11
sigma_file = f'../Sigma_IT/ID_Sigma_IT/ID_Sigma_IT_{model_num}_Delay_Dec.csv'
df_sigma = pd.read_csv(sigma_file)
sigma_list = df_sigma['Sigma'].round(3).tolist()
InverseTTA_Coef_list = df_sigma['InverseTTA_Coef'].round(3).tolist()

df_Sigma_IT = pd.DataFrame()
print(len(df_sigma))
csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
for i in range(len(df_sigma)):
    sigma = sigma_list[i]
    Inverse_TTA_Coef = InverseTTA_Coef_list[i]
    k = None
    csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_{input}_Test{k}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df = pd.read_csv(csv_file)
    df_Sigma_IT = pd.concat([df_Sigma_IT, df], ignore_index=True)
    print(f'sigma:{sigma};csvname:{csv_file}')


model_num = 0
input = 10
sigma_file = f'../Sigma/ID_Sigma/ID_Sigma_{model_num}_Dec.csv'
df_sigma = pd.read_csv(sigma_file)
sigma_list = df_sigma['Sigma'].round(3).tolist()
df_Sigma = pd.DataFrame()
print(len(df_sigma))
csv_dir = f'../Sim_Data/DQN_Sigma_Input/Sim_data_{model_num}_Delay_Dec'
for i in range(len(df_sigma)):
    sigma = sigma_list[i]
    k = None
    csvname = f'Sigma_{sigma}_Input_{input}_Test{k}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df = pd.read_csv(csv_file)
    df_Sigma = pd.concat([df_Sigma, df], ignore_index=True)
    print(f'sigma:{sigma};csvname:{csv_file}')


model_num = 0
input = 8
sigma_file = f'../IT/ID_IT/ID_IT_{model_num}_Delay_Dec.csv'
df_IT = pd.read_csv(sigma_file)
IT_list = df_IT['Inverse_TTA_Coef'].round(3).tolist()

df_IT = pd.DataFrame()
print(len(df_sigma))
csv_dir = f'../Sim_Data/DQN_IT_Input/Sim_data_{model_num}_Delay_Dec'
for i in range(len(df_sigma)):
    IT = IT_list[i]
    k = None
    csvname = f'InverseTTA_{IT}_Input_{input}_Test{k}.csv'
    # csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_<built-in function input>_Test{k}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df = pd.read_csv(csv_file)
    df_IT = pd.concat([df_IT, df], ignore_index=True)
    print(f'InverseTTA:{IT};csvname:{csv_file}')

def SimMean(df):
    # df = df_all
    # df = df.dropna(axis=0)
    df = df[df['score'] == 1]
    gap23 = df['time_gap'] == 2.3
    gap46 = df['time_gap'] == 4.6
    gap69 = df['time_gap'] == 6.9

    speed25 = df['speed'] == 6.94
    speed30 = df['speed'] == 13.89
    acc0 = df['acceleration'] == 0
    acc1 = df['acceleration'] == 2.02
    acc2 = df['acceleration'] == 3.47
    acc3 = df['acceleration'] == 4.05
    acc4 = df['acceleration'] == 0.87
    acc5 = df['acceleration'] == 1.62
    acc6 = df['acceleration'] == 1.73
    acc7 = df['acceleration'] == 0.55
    acc8 = df['acceleration'] == 1.06


    start6_2 = df['start_time'][speed25][gap23][acc0].tolist()
    start6_2.sort()
    start6_4 = df['start_time'][speed25][gap46][acc0].tolist()
    start6_4.sort()
    start6_6 = df['start_time'][speed25][gap69][acc0].tolist()
    start6_6.sort()
    start13_2 = df['start_time'][speed30][gap23][acc0].tolist()
    start13_2.sort()
    start13_4 = df['start_time'][speed30][gap46][acc0].tolist()
    start13_4.sort()
    start13_6 = df['start_time'][speed30][gap69][acc0].tolist()
    start13_6.sort()

    start6_2_4 = df['start_time'][speed25][gap23][acc1].tolist()
    start6_2_4.sort()
    start13_2_4 = df['start_time'][speed30][gap23][acc2].tolist()
    start13_2_4.sort()
    start13_2_8 = df['start_time'][speed30][gap23][acc3].tolist()
    start13_2_8.sort()
    start6_4_4 = df['start_time'][speed25][gap46][acc4].tolist()
    start6_4_4.sort()
    start13_4_4 = df['start_time'][speed30][gap46][acc5].tolist()
    start13_4_4.sort()
    start13_4_8 = df['start_time'][speed30][gap46][acc6].tolist()
    start13_4_8.sort()
    start6_6_4 = df['start_time'][speed25][gap69][acc7].tolist()
    start6_6_4.sort()
    start13_6_4 = df['start_time'][speed30][gap69][acc8].tolist()
    start13_6_4.sort()
    mean_constant = [np.mean(start6_2),np.mean(start6_4),np.mean(start6_6),np.mean(start13_2),np.mean(start13_4),np.mean(start13_6)]
    mean_deceleration = [np.mean(start6_2_4),np.mean(start13_2_4),np.mean(start13_2_8),np.mean(start6_4_4),
                         np.mean(start13_4_4),np.mean(start13_4_8),np.mean(start6_6_4),np.mean(start13_6_4)]
    return mean_constant,mean_deceleration

def ExpMean():
    path = "./Exp_data"
    ExpName = path + '/d2p_cross_times_uk.csv'
    crossing_data = pd.read_csv(ExpName)
    df_exp = pd.DataFrame(crossing_data)

    mask6_2_0 = df_exp['trial_id'] == 6
    mask6_4_0 = df_exp['trial_id'] == 4
    mask6_6_0 = df_exp['trial_id'] == 8
    mask13_2_0 = df_exp['trial_id'] == 5
    mask13_4_0 = df_exp['trial_id'] == 3
    mask13_6_0 = df_exp['trial_id'] == 7

    mask13_4_4 = df_exp['trial_id'] == 9
    mask13_2_4 = df_exp['trial_id'] == 10
    mask13_6_4 = df_exp['trial_id'] == 11
    mask6_4_4 = df_exp['trial_id'] == 12
    mask6_2_4 = df_exp['trial_id'] == 13
    mask6_6_4 = df_exp['trial_id'] == 14

    mask13_2_8 = df_exp['trial_id'] == 15
    mask13_4_8 = df_exp['trial_id'] == 16

    start6_2_EXP = df_exp[mask6_2_0]['cross_time'].tolist()
    start6_2_EXP.sort()
    start6_4_EXP = df_exp[mask6_4_0]['cross_time'].tolist()
    start6_4_EXP.sort()
    start6_6_EXP = df_exp[mask6_6_0]['cross_time'].tolist()
    start6_6_EXP.sort()
    start13_2_EXP = df_exp[mask13_2_0]['cross_time'].tolist()
    start13_2_EXP.sort()
    start13_4_EXP = df_exp[mask13_4_0]['cross_time'].tolist()
    start13_4_EXP.sort()
    start13_6_EXP = df_exp[mask13_6_0]['cross_time'].tolist()
    start13_6_EXP.sort()
    start13_4_4_EXP = df_exp[mask13_4_4]['cross_time'].tolist()
    start13_4_4_EXP.sort()
    start13_2_4_EXP = df_exp[mask13_2_4]['cross_time'].tolist()
    start13_2_4_EXP.sort()
    start13_6_4_EXP = df_exp[mask13_6_4]['cross_time'].tolist()
    start13_6_4_EXP.sort()
    start6_4_4_EXP = df_exp[mask6_4_4]['cross_time'].tolist()
    start6_4_4_EXP.sort()
    start6_2_4_EXP = df_exp[mask6_2_4]['cross_time'].tolist()
    start6_2_4_EXP.sort()
    start6_6_4_EXP = df_exp[mask6_6_4]['cross_time'].tolist()
    start6_6_4_EXP.sort()
    start13_2_8_EXP = df_exp[mask13_2_8]['cross_time'].tolist()
    start13_2_8_EXP.sort()
    start13_4_8_EXP = df_exp[mask13_4_8]['cross_time'].tolist()
    start13_4_8_EXP.sort()
    mean_constant = [np.mean(start6_2_EXP),np.mean(start6_4_EXP),np.mean(start6_6_EXP),np.mean(start13_2_EXP),
                     np.mean(start13_4_EXP),np.mean(start13_6_EXP)]
    mean_deceleration = [np.mean(start6_2_4_EXP),np.mean(start13_2_4_EXP),np.mean(start13_2_8_EXP),np.mean(start6_4_4_EXP),
                         np.mean(start13_4_4_EXP),np.mean(start13_4_8_EXP),np.mean(start6_6_4_EXP),np.mean(start13_6_4_EXP)]
    return mean_constant,mean_deceleration

def calculate_mad(simulation_values, experiment_values):
    """Calculate Mean Absolute Deviation (MAD) between simulation and experiment values."""
    differences = np.abs(np.array(simulation_values) - np.array(experiment_values))
    return np.mean(differences)
if __name__ == '__main__':
    print(df_Sigma)
    Sim_mean_constant_IO, Sim_mean_deceleration_IO = SimMean(df_IO)
    print(Sim_mean_constant_IO,Sim_mean_deceleration_IO)

    Sim_mean_constant_Sigma, Sim_mean_deceleration_Sigma = SimMean(df_Sigma)
    print(Sim_mean_constant_Sigma,Sim_mean_deceleration_Sigma)

    Sim_mean_constant_IT, Sim_mean_deceleration_IT = SimMean(df_IT)
    print(Sim_mean_constant_IT,Sim_mean_deceleration_IT)

    Sim_mean_constant_Sigma_IT, Sim_mean_deceleration_Sigma_IT = SimMean(df_Sigma_IT)
    print(Sim_mean_constant_Sigma_IT, Sim_mean_deceleration_Sigma_IT)

    Exp_mean_constant, Exp_mean_deceleration = ExpMean()
    # plt.style.use('seaborn')

    fig = plt.figure(figsize=(13, 10))
    gs = GridSpec(10, 10, figure=fig)
    leftlabel_font = 30
    legend_font = 23
    title_font = 30
    text_font = 22
    label_size = 24

    # Subplots for Gap Plot
    ax1 = fig.add_subplot(gs[5:10, 5:10])
    ax2 = fig.add_subplot(gs[5:10, 0:5])
    ax3 = fig.add_subplot(gs[0:5, 5:10])
    ax4 = fig.add_subplot(gs[0:5, 0:5])
    ax1.scatter(Sim_mean_constant_Sigma_IT, Exp_mean_constant,c='green', label='Constant-Speed')
    ax1.scatter(Sim_mean_deceleration_Sigma_IT, Exp_mean_deceleration,c='orange', label='Yielding')
    ax2.scatter(Sim_mean_constant_Sigma, Exp_mean_constant,c='green', label='Constant-Speed')
    ax2.scatter(Sim_mean_deceleration_Sigma, Exp_mean_deceleration,c='orange', label='Yielding')
    ax3.scatter(Sim_mean_constant_IT, Exp_mean_constant,c='green', label='Constant-Speed')
    ax3.scatter(Sim_mean_deceleration_IT, Exp_mean_deceleration,c='orange', label='Yielding')
    ax4.scatter(Sim_mean_constant_IO, Exp_mean_constant,c='green', label='Constant-Speed')
    ax4.scatter(Sim_mean_deceleration_IO, Exp_mean_deceleration,c='orange', label='Yielding')
    fig.text(0.5, -0.01, 'Mean predicted CIT (s)', ha='center', va='center', fontsize=leftlabel_font)
    fig.text(-0.01, 0.5, 'Mean observed CIT (s)', va='center', ha='center', rotation='vertical',
             fontsize=leftlabel_font)

    lims = 5.4
    lower_lim = -0.2
    ax1.set_xlim(lower_lim,lims)
    ax1.set_ylim(lower_lim,lims)

    ax1.plot([lower_lim,lims],[lower_lim,lims], 'k',linestyle='--', alpha=0.75)

    ax2.plot([lower_lim,lims],[lower_lim,lims], 'k',linestyle='--', alpha=0.75)
    ax3.plot([lower_lim,lims],[lower_lim,lims], 'k',linestyle='--', alpha=0.75)
    ax4.plot([lower_lim,lims],[lower_lim,lims], 'k',linestyle='--', alpha=0.75)
    ax4.legend(fontsize = legend_font,loc='upper left', bbox_to_anchor=(0.05, 1))
    # ax5.plot([0,5],[0,5], 'k',linestyle='--', alpha=0.75)
    # ax5.legend()
    ax2.set_xlim(lower_lim,lims)
    ax2.set_ylim(lower_lim,lims)
    ax4.xaxis.set_ticklabels([])
    ax3.xaxis.set_ticklabels([])
    ax3.yaxis.set_ticklabels([])
    ax1.yaxis.set_ticklabels([])
    ax4.tick_params(axis='y', which='major', labelsize=label_size)
    ax2.tick_params(axis='both', which='major', labelsize=label_size)
    ax1.tick_params(axis='x', which='major', labelsize=label_size)
    # ax3.tick_params(axis='y', which='major', labelsize=label_size)

    # ax1.tick_params(axis='x', which='major', labelsize=label_size)

    # ax1.set_title('Sigma_IT_NC_Delay', fontsize=title_font)
    ax1.set_title('VLM', fontsize=title_font)
    ax2.set_title('VM', fontsize=title_font)
    ax3.set_title('LM', fontsize=title_font)
    ax4.set_title('BM', fontsize=title_font)

    ax3.set_xlim(lower_lim,lims)
    ax3.set_ylim(lower_lim,lims)

    ax4.set_xlim(lower_lim,lims)
    ax4.set_ylim(lower_lim,lims)

    MAD_constant_Sigma_IT = calculate_mad(Sim_mean_constant_Sigma_IT, Exp_mean_constant)
    MAD_deceleration_Sigma_IT = calculate_mad(Sim_mean_deceleration_Sigma_IT, Exp_mean_deceleration)
    MAD_overall_Sigma_IT = calculate_mad(Sim_mean_constant_Sigma_IT + Sim_mean_deceleration_Sigma_IT, Exp_mean_constant + Exp_mean_deceleration)

    print("MAD (Constant-Speed)_Sigma_IT:", MAD_constant_Sigma_IT)
    print("MAD (Yielding)_Sigma_IT:", MAD_deceleration_Sigma_IT)
    print("MAD (Overall)_Sigma_IT:", MAD_overall_Sigma_IT)
    ax1.text(5.4,0.8, f"MAD (Constant-Speed): {MAD_constant_Sigma_IT:.2f} s", ha='right', fontsize=text_font)
    ax1.text(5.4, 0.35, f"MAD (Yielding): {MAD_deceleration_Sigma_IT:.2f} s", ha='right', fontsize=text_font)
    ax1.text(5.4, -0.1, f"MAD (Overall): {MAD_overall_Sigma_IT:.2f} s", ha='right', fontsize=text_font)

    MAD_constant_Sigma = calculate_mad(Sim_mean_constant_Sigma, Exp_mean_constant)
    MAD_deceleration_Sigma = calculate_mad(Sim_mean_deceleration_Sigma, Exp_mean_deceleration)
    MAD_overall_Sigma = calculate_mad(Sim_mean_constant_Sigma + Sim_mean_deceleration_Sigma, Exp_mean_constant + Exp_mean_deceleration)

    print("MAD (Constant-Speed)_Sigma:", MAD_constant_Sigma)
    print("MAD (Yielding)_Sigma:", MAD_deceleration_Sigma)
    print("MAD (Overall)_Sigma:", MAD_overall_Sigma)
    ax2.text(5.4,0.8, f"MAD (Constant-Speed): {MAD_constant_Sigma:.2f} s", ha='right', fontsize=text_font)
    ax2.text(5.4, 0.35, f"MAD (Yielding): {MAD_deceleration_Sigma:.2f} s", ha='right', fontsize=text_font)
    ax2.text(5.4, -0.1, f"MAD (Overall): {MAD_overall_Sigma:.2f} s", ha='right', fontsize=text_font)

    MAD_constant_IT = calculate_mad(Sim_mean_constant_IT, Exp_mean_constant)
    MAD_deceleration_IT = calculate_mad(Sim_mean_deceleration_IT, Exp_mean_deceleration)
    MAD_overall_IT = calculate_mad(Sim_mean_constant_IT + Sim_mean_deceleration_IT, Exp_mean_constant + Exp_mean_deceleration)

    print("MAD (Constant-Speed)_IT:", MAD_constant_IT)
    print("MAD (Yielding)_IT:", MAD_deceleration_IT)
    print("MAD (Overall)_IT:", MAD_overall_IT)
    ax3.text(5.4,0.8, f"MAD (Constant-Speed): {MAD_constant_IT:.2f} s", ha='right', fontsize=text_font)
    ax3.text(5.4, 0.35, f"MAD (Yielding): {MAD_deceleration_IT:.2f} s", ha='right', fontsize=text_font)
    ax3.text(5.4, -0.1, f"MAD (Overall): {MAD_overall_IT:.2f} s", ha='right', fontsize=text_font)

    MAD_constant_IO = calculate_mad(Sim_mean_constant_IO, Exp_mean_constant)
    MAD_deceleration_IO = calculate_mad(Sim_mean_deceleration_IO, Exp_mean_deceleration)
    MAD_overall_IO = calculate_mad(Sim_mean_constant_IO + Sim_mean_deceleration_IO, Exp_mean_constant + Exp_mean_deceleration)

    print("MAD (Constant-Speed)_IO:", MAD_constant_IO)
    print("MAD (Yielding)_IO:", MAD_deceleration_IO)
    print("MAD (Overall)_IO:", MAD_overall_IO)
    ax4.text(5.4,0.8, f"MAD (Constant-Speed): {MAD_constant_IO:.2f} s", ha='right', fontsize=text_font)
    ax4.text(5.4, 0.35, f"MAD (Yielding): {MAD_deceleration_IO:.2f} s", ha='right', fontsize=text_font)
    ax4.text(5.4, -0.1, f"MAD (Overall): {MAD_overall_IO:.2f} s", ha='right', fontsize=text_font)

    plot_dir = 'Plot'
    name = f'MAD_Ablation.png'
    PlotName = os.path.join(plot_dir, name)
    plt.tight_layout()
    plt.savefig(PlotName, dpi=300, bbox_inches='tight')
    plt.show()
