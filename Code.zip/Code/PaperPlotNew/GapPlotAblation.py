import matplotlib.pyplot as plt
import numpy as np
import gym
from matplotlib.gridspec import GridSpec
import pandas as pd
import os
import seaborn as sns
orange = (247 / 255, 144 / 255, 61 / 255)
blue = (77 / 255, 133 / 255, 189 / 255)
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("Working directory set to:", os.getcwd())
def Gap(df):
    df = df[df['score'] == 1]
    gap10_speed25 = (df['time_gap'] == 1) & (df['speed'] == 6.94) & (df['acceleration'] == 0)
    gap10_speed30 = (df['time_gap'] == 1) & (df['speed'] == 13.89) & (df['acceleration'] == 0)
    gap23_speed25 = (df['time_gap'] == 2.3) & (df['speed'] == 6.94) & (df['acceleration'] == 0)
    gap23_speed30 = (df['time_gap'] == 2.3) & (df['speed'] == 13.89) & (df['acceleration'] == 0)
    gap46_speed25 = (df['time_gap'] == 4.6) & (df['speed'] == 6.94) & (df['acceleration'] == 0)
    gap46_speed30 = (df['time_gap'] == 4.6) & (df['speed'] == 13.89) & (df['acceleration'] == 0)
    gap69_speed25 = (df['time_gap'] == 6.9) & (df['speed'] == 6.94) & (df['acceleration'] == 0)
    gap69_speed30 = (df['time_gap'] == 6.9) & (df['speed'] == 13.89) & (df['acceleration'] == 0)

    acc_prob25 = [
        len(df['gap_accept'][gap10_speed25][df['gap_accept'][gap10_speed25] == 1]) / len(
            df['gap_accept'][gap10_speed25]),

        len(df['gap_accept'][gap23_speed25][df['gap_accept'][gap23_speed25] == 1]) / len(
            df['gap_accept'][gap23_speed25]),

        len(df['gap_accept'][gap46_speed25][df['gap_accept'][gap46_speed25] == 1]) / len(
            df['gap_accept'][gap46_speed25]),

        len(df['gap_accept'][gap69_speed25][df['gap_accept'][gap69_speed25] == 1]) / len(
            df['gap_accept'][gap69_speed25])]

    acc_prob30 = [
        len(df['gap_accept'][gap10_speed30][df['gap_accept'][gap10_speed30] == 1]) / len(
            df['gap_accept'][gap10_speed30]),

        len(df['gap_accept'][gap23_speed30][df['gap_accept'][gap23_speed30] == 1]) / len(
            df['gap_accept'][gap23_speed30]),

        len(df['gap_accept'][gap46_speed30][df['gap_accept'][gap46_speed30] == 1]) / len(
            df['gap_accept'][gap46_speed30]),

        len(df['gap_accept'][gap69_speed30][df['gap_accept'][gap69_speed30] == 1]) / len(
            df['gap_accept'][gap69_speed30])]
    return acc_prob25,acc_prob30

def plotLearning():

    model_num = 'IO'
    input = 5
    num = None
    csv_dir = f'../Sim_Data/Sim_data_{model_num}_Dec'
    df_all = pd.DataFrame()
    csvname = f'Input_{input}_Test{num}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df_all = pd.read_csv(csv_file)
    acc_prob25_IO, acc_prob30_IO = Gap(df_all)

    model_num = 0
    input = 11
    sigma_file = f'../Sigma_IT/ID_Sigma_IT/ID_Sigma_IT_{model_num}_Delay_Dec.csv'
    df_sigma = pd.read_csv(sigma_file)
    sigma_list = df_sigma['Sigma'].round(3).tolist()
    InverseTTA_Coef_list = df_sigma['InverseTTA_Coef'].round(3).tolist()

    df_all = pd.DataFrame()
    print(len(df_sigma))
    csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
    for i in range(len(df_sigma)):
        sigma = sigma_list[i]
        Inverse_TTA_Coef = InverseTTA_Coef_list[i]
        k = None
        csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_{input}_Test{k}.csv'
        csv_file = os.path.join(csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df_all = pd.concat([df_all, df], ignore_index=True)
        print(f'sigma:{sigma};csvname:{csv_file}')
    acc_prob25_Sigma_IT, acc_prob30_Sigma_IT = Gap(df_all)

    model_num = 0
    input = 10
    sigma_file = f'../Sigma/ID_Sigma/ID_Sigma_{model_num}_Dec.csv'
    df_sigma = pd.read_csv(sigma_file)
    sigma_list = df_sigma['Sigma'].round(3).tolist()
    df_all = pd.DataFrame()
    print(len(df_sigma))
    csv_dir = f'../Sim_Data/DQN_Sigma_Input/Sim_data_{model_num}_Delay_Dec'
    for i in range(len(df_sigma)):
        sigma = sigma_list[i]
        k = None
        csvname = f'Sigma_{sigma}_Input_{input}_Test{k}.csv'
        csv_file = os.path.join(csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df_all = pd.concat([df_all, df], ignore_index=True)
        print(f'sigma:{sigma};csvname:{csv_file}')
    acc_prob25_Sigma, acc_prob30_Sigma = Gap(df_all)

    model_num = 0
    input = 8
    sigma_file = f'../IT/ID_IT/ID_IT_{model_num}_Delay_Dec.csv'
    df_IT = pd.read_csv(sigma_file)
    IT_list = df_IT['Inverse_TTA_Coef'].round(3).tolist()

    df_all = pd.DataFrame()
    print(len(df_sigma))
    csv_dir = f'../Sim_Data/DQN_IT_Input/Sim_data_{model_num}_Delay_Dec'
    for i in range(len(df_sigma)):
        IT = IT_list[i]
        k = None
        csvname = f'InverseTTA_{IT}_Input_{input}_Test{k}.csv'
        # csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_<built-in function input>_Test{k}.csv'
        csv_file = os.path.join(csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df_all = pd.concat([df_all, df], ignore_index=True)
        print(f'InverseTTA:{IT};csvname:{csv_file}')
    acc_prob25_IT, acc_prob30_IT= Gap(df_all)


    # gap = [1, 1.5, 2.29, 3.5, 4.58, 5.5, 6.87]
    gap = [1, 2.29,4.58, 6.87]

    gap_exp = [2.29, 4.58, 6.87]
    exp_acc_prob25=[0.05, 0.4, 0.75]
    exp_acc_prob30=[0.05, 0.7, 0.95]
    collision_num = []
    collision_rates = []
    for i in range(len(df['collision'])):
        if df.iloc[i]['collision'] == 1:
            collision_num.append(1)
        else:
            pass
        collision_rate = len(collision_num)/(i+1)
        collision_rates.append(collision_rate)


    fig = plt.figure(figsize=(14,10))
    gs = GridSpec(10, 10, figure=fig)
    leftlabel_font = 26
    legend_font = 20
    title_font = 26
    text_font = 26
    label_size = 26
    # Subplots for Gap Plot
    ax1 = fig.add_subplot(gs[0:5, 0:5])
    ax2 = fig.add_subplot(gs[0:5, 5:10])
    ax3 = fig.add_subplot(gs[5:10, 0:5])
    ax4 = fig.add_subplot(gs[5:10, 5:10])
    # # Subplots for CIT Plot
    rightlabel_font = 10
    leftlabel_font = 30
    title_font = 30
    tick_size = 22
    marker_size = 60
    legend_size = 14
    linewidth = 5
    alpha = 0.8

    # ax1.set_ylabel('Gap acceptance rate', fontsize=leftlabel_font)
    ax1.yaxis.set_label_position("left")

    ax1.scatter(gap_exp, exp_acc_prob25, alpha=0.75, color=blue, marker='o', label='Human 6.9 m/s', s=marker_size)
    ax1.scatter(gap_exp, exp_acc_prob30, alpha=0.75, color=orange, marker='o', label='Human 13.9 m/s', s=marker_size)
    ax1.plot(gap, acc_prob25_IO, alpha=0.75, color=blue, label='Model 6.9 m/s',linewidth = linewidth)
    ax1.plot(gap, acc_prob30_IO, alpha=0.75, color=orange, label='Model 13.9 m/s',linewidth = linewidth)
    ax1.set_title('BM', fontsize=title_font)
    ax1.xaxis.set_tick_params(labelsize=tick_size)
    ax1.set_xlim(0.5,7.7)
    ax1.set_ylim(-0.11, 1.1)
    ax1.set_xticks([1, 2.3, 4.6, 6.9])


    ax2.scatter(gap_exp, exp_acc_prob25, alpha=0.75, color=blue, marker='o', label='Human 6.9 m/s', s=marker_size)
    ax2.scatter(gap_exp, exp_acc_prob30, alpha=0.75, color=orange, marker='o', label='Human 13.9 m/s', s=marker_size)
    ax2.plot(gap, acc_prob25_IT, alpha=0.75, color=blue, label='Model 6.9 m/s',linewidth = linewidth)
    ax2.plot(gap, acc_prob30_IT, alpha=0.75, color=orange, label='Model 13.9 m/s',linewidth = linewidth)
    ax2.xaxis.set_tick_params(labelsize=tick_size)
    ax2.set_title('LM', fontsize=title_font)
    # ax2.set_xlabel("Initial TTA (s)", size=title_font,labelpad=20)
    ax2.xaxis.set_label_coords(1, -0.1)
    ax2.set_xlim(0.5,7.7)
    ax2.set_ylim(-0.11, 1.1)
    ax2.set_xticks([1, 2.3, 4.6, 6.9])

    ax3.scatter(gap_exp, exp_acc_prob25, alpha=0.75, color=blue, marker='o', label='Human 6.9 m/s', s=marker_size)
    ax3.scatter(gap_exp, exp_acc_prob30, alpha=0.75, color=orange, marker='o', label='Human 13.9 m/s', s=marker_size)
    ax3.plot(gap, acc_prob25_Sigma, alpha=0.75, color=blue, label='Model 6.9 m/s',linewidth = linewidth)
    ax3.plot(gap, acc_prob30_Sigma, alpha=0.75, color=orange, label='Model 13.9 m/s',linewidth = linewidth)
    # ax3.xaxis.set_tick_params(labelsize=tick_size)
    ax3.set_title('VM', fontsize=title_font)
    ax3.set_xlim(0.5,7.7)
    ax3.set_ylim(-0.11, 1.1)
    ax3.set_xticks([1, 2.3, 4.6, 6.9])

    ax4.scatter(gap_exp, exp_acc_prob25, alpha=0.75, color=blue, marker='o', label='Human 6.9 m/s', s=marker_size)
    ax4.scatter(gap_exp, exp_acc_prob30, alpha=0.75, color=orange, marker='o', label='Human 13.9 m/s', s=marker_size)
    ax4.plot(gap, acc_prob25_Sigma_IT, alpha=0.75, color=blue, label='Model 6.9 m/s',linewidth = linewidth)
    ax4.plot(gap, acc_prob30_Sigma_IT, alpha=0.75, color=orange, label='Model 13.9 m/s',linewidth = linewidth)
    ax4.xaxis.set_tick_params(labelsize=tick_size)
    ax4.legend(prop={'size': legend_font}, loc='lower right',bbox_to_anchor=(1.03,-0.044), framealpha=0.5)
    ax4.set_title('VLM', fontsize=title_font)
    ax4.set_xlim(0.5,7.7)
    ax4.set_ylim(-0.11, 1.1)
    ax4.set_xticks([1, 2.3, 4.6, 6.9])
    fig.text(0.5, -0.01, 'Initial TTA (s)', ha='center', va='center', fontsize=leftlabel_font)
    fig.text(-0.01, 0.5, 'Gap acceptance rate', va='center', ha='center', rotation='vertical',
             fontsize=leftlabel_font)
    ax1.xaxis.set_ticklabels([])
    ax2.xaxis.set_ticklabels([])
    ax2.yaxis.set_ticklabels([])
    ax4.yaxis.set_ticklabels([])
    ax1.tick_params(axis='both', which='major', labelsize=label_size)
    ax2.tick_params(axis='x', which='major', labelsize=label_size)
    ax3.tick_params(axis='y', which='major', labelsize=label_size)
    ax3.tick_params(axis='x', which='major', labelsize=label_size)
    ax4.tick_params(axis='x', which='major', labelsize=label_size)

    combined_plotname = f'GapPlotAblation.png'

    combined_plot = os.path.join(plot_dir, combined_plotname)
    plt.tight_layout()

    plt.savefig(combined_plot, dpi=300, bbox_inches='tight')

    plt.show()

plot_dir = 'Plot'
os.makedirs(plot_dir, exist_ok=True)


if __name__ == '__main__':
    plotLearning()