import pandas as pd
import os
def LoadExpCIT(ExpName):
    crossname = ExpName
    crossing_data = pd.read_csv(crossname)
    df_exp = pd.DataFrame(crossing_data)
    v6 = 6.9
    v13 = 13.9
    vp = 1.31
    w = 1.95
    l = 4.95
    dp = 2.5
    dt6 = l/v6
    dt13 = l/v13
    dtp = w/vp
    tpv = dp/vp

    mask6_2_0 = df_exp['trial_id'] == 6
    mask6_4_0 = df_exp['trial_id'] == 4
    mask6_6_0 = df_exp['trial_id'] == 8
    mask13_2_0 = df_exp['trial_id'] == 5
    mask13_4_0 = df_exp['trial_id'] == 3
    mask13_6_0 = df_exp['trial_id'] == 7

    mask13_4_4 = df_exp['trial_id'] == 9
    mask13_2_4 = df_exp['trial_id'] == 10
    mask13_6_4 = df_exp['trial_id'] == 11
    mask6_4_4 = df_exp['trial_id'] == 12
    mask6_2_4 = df_exp['trial_id'] == 13
    mask6_6_4 = df_exp['trial_id'] == 14

    mask13_2_8 = df_exp['trial_id'] == 15
    mask13_4_8 = df_exp['trial_id'] == 16

    start6_2_0 = df_exp[mask6_2_0]['cross_time'].tolist()
    start6_2_0.sort()
    collision_count6_2 = sum(1 for number in start6_2_0 if (2.3-dtp-tpv) < number < 2.3+dt6-tpv)
    collision_rate6_2 = collision_count6_2 / len(start6_2_0)

    start6_4_0 = df_exp[mask6_4_0]['cross_time'].tolist()
    start6_4_0.sort()
    collision_count6_4 = sum(1 for number in start6_4_0 if (4.6-dtp-tpv) < number < 4.6+dt6-tpv)
    collision_rate6_4 = collision_count6_4 / len(start6_4_0)

    start6_6_0 = df_exp[mask6_6_0]['cross_time'].tolist()
    start6_6_0.sort()
    collision_count6_6 = sum(1 for number in start6_6_0 if (6.9-dtp-tpv) < number < 6.9+dt6-tpv)
    collision_rate6_6 = collision_count6_6 / len(start6_6_0)

    start13_2_0 = df_exp[mask13_2_0]['cross_time'].tolist()
    start13_2_0.sort()
    collision_count13_2 = sum(1 for number in start13_2_0 if (2.3-dtp-tpv) < number < 2.3+dt13-tpv)
    collision_rate13_2 = collision_count13_2 / len(start13_2_0)

    start13_4_0 = df_exp[mask13_4_0]['cross_time'].tolist()
    start13_4_0.sort()
    collision_count13_4 = sum(1 for number in start13_4_0 if (4.6-dtp-tpv) < number < 4.6+dt13-tpv)
    collision_rate13_4 = collision_count13_4 / len(start13_4_0)

    start13_6_0 = df_exp[mask13_6_0]['cross_time'].tolist()
    start13_6_0.sort()
    collision_count13_6 = sum(1 for number in start13_6_0 if (6.9-dtp-tpv) < number < 6.9+dt13-tpv)
    collision_rate13_6 = collision_count13_6 / len(start13_6_0)
    print(collision_rate6_2,collision_rate6_4,collision_rate6_6,collision_rate13_2,collision_rate13_4,collision_rate13_6)
    collision_rate = collision_rate6_2+collision_rate6_4+collision_rate6_6+collision_rate13_6+collision_rate13_4+collision_rate13_2
    print(collision_rate)
    start13_4_4 = df_exp[mask13_4_4]['cross_time'].tolist()
    start13_4_4.sort()
    start13_2_4 = df_exp[mask13_2_4]['cross_time'].tolist()
    start13_2_4.sort()
    start13_6_4 = df_exp[mask13_6_4]['cross_time'].tolist()
    start13_6_4.sort()
    start6_4_4 = df_exp[mask6_4_4]['cross_time'].tolist()
    start6_4_4.sort()
    start6_2_4 = df_exp[mask6_2_4]['cross_time'].tolist()
    start6_2_4.sort()
    start6_6_4 = df_exp[mask6_6_4]['cross_time'].tolist()
    start6_6_4.sort()
    start13_2_8 = df_exp[mask13_2_8]['cross_time'].tolist()
    start13_2_8.sort()
    start13_4_8 = df_exp[mask13_4_8]['cross_time'].tolist()
    start13_4_8.sort()


    x6_2_0_exp = [0]
    y6_2_0_exp = [0]
    for i in range(len(start6_2_0)):
        x6_2_0_exp.append(start6_2_0[i])
        y6_2_0_exp.append((i + 1) / len(start6_2_0))
    # x6_2_0_exp.append(15)
    x6_2_0_exp.append(16)
    y6_2_0_exp.append(1)

    x6_4_0_exp = [0]
    y6_4_0_exp = [0]
    for i in range(len(start6_4_0)):
        x6_4_0_exp.append(start6_4_0[i])
        y6_4_0_exp.append((i + 1) / len(start6_4_0))
    x6_4_0_exp.append(16)
    y6_4_0_exp.append(1)

    x6_6_0_exp = [0]
    y6_6_0_exp = [0]
    for i in range(len(start6_6_0)):
        x6_6_0_exp.append(start6_6_0[i])
        y6_6_0_exp.append((i + 1) / len(start6_6_0))
    x6_6_0_exp.append(16)
    y6_6_0_exp.append(1)

    x13_2_0_exp = [0]
    y13_2_0_exp = [0]
    for i in range(len(start13_2_0)):
        x13_2_0_exp.append(start13_2_0[i])
        y13_2_0_exp.append((i + 1) / len(start13_2_0))
    x13_2_0_exp.append(16)
    y13_2_0_exp.append(1)

    x13_4_0_exp = [0]
    y13_4_0_exp = [0]
    for i in range(len(start13_4_0)):
        x13_4_0_exp.append(start13_4_0[i])
        y13_4_0_exp.append((i + 1) / len(start13_4_0))
    x13_4_0_exp.append(16)
    y13_4_0_exp.append(1)

    x13_6_0_exp = [0]
    y13_6_0_exp = [0]
    for i in range(len(start13_6_0)):
        x13_6_0_exp.append(start13_6_0[i])
        y13_6_0_exp.append((i + 1) / len(start13_6_0))
    x13_6_0_exp.append(16)
    y13_6_0_exp.append(1)

    x13_4_4_exp = [0]
    y13_4_4_exp = [0]
    for i in range(len(start13_4_4)):
        x13_4_4_exp.append(start13_4_4[i])
        y13_4_4_exp.append((i + 1) / len(start13_4_4))
    x13_4_4_exp.append(16)
    y13_4_4_exp.append(1)

    x13_2_4_exp = [0]
    y13_2_4_exp = [0]
    for i in range(len(start13_2_4)):
        x13_2_4_exp.append(start13_2_4[i])
        y13_2_4_exp.append((i + 1) / len(start13_2_4))
    x13_2_4_exp.append(16)
    y13_2_4_exp.append(1)

    x13_6_4_exp = [0]
    y13_6_4_exp = [0]
    for i in range(len(start13_6_4)):
        x13_6_4_exp.append(start13_6_4[i])
        y13_6_4_exp.append((i + 1) / len(start13_6_4))
    x13_6_4_exp.append(16)
    y13_6_4_exp.append(1)

    x6_4_4_exp = [0]
    y6_4_4_exp = [0]
    for i in range(len(start6_4_4)):
        x6_4_4_exp.append(start6_4_4[i])
        y6_4_4_exp.append((i + 1) / len(start6_4_4))
    x6_4_4_exp.append(16)
    y6_4_4_exp.append(1)

    x6_2_4_exp = [0]
    y6_2_4_exp = [0]
    for i in range(len(start6_2_4)):
        x6_2_4_exp.append(start6_2_4[i])
        y6_2_4_exp.append((i + 1) / len(start6_2_4))
    x6_2_4_exp.append(16)
    y6_2_4_exp.append(1)

    x6_6_4_exp = [0]
    y6_6_4_exp = [0]
    for i in range(len(start6_6_4)):
        x6_6_4_exp.append(start6_6_4[i])
        y6_6_4_exp.append((i + 1) / len(start6_6_4))
    x6_6_4_exp.append(16)
    y6_6_4_exp.append(1)

    x13_2_8_exp = [0]
    y13_2_8_exp = [0]
    for i in range(len(start13_2_8)):
        x13_2_8_exp.append(start13_2_8[i])
        y13_2_8_exp.append((i + 1) / len(start13_2_8))
    x13_2_8_exp.append(16)
    y13_2_8_exp.append(1)

    x13_4_8_exp = [0]
    y13_4_8_exp = [0]
    for i in range(len(start13_4_8)):
        x13_4_8_exp.append(start13_4_8[i])
        y13_4_8_exp.append((i + 1) / len(start13_4_8))
    x13_4_8_exp.append(16)
    y13_4_8_exp.append(1)

    return x6_2_0_exp, x6_4_0_exp, x6_6_0_exp, x13_2_0_exp, x13_4_0_exp, x13_6_0_exp,\
           y6_2_0_exp, y6_4_0_exp, y6_6_0_exp, y13_2_0_exp, y13_4_0_exp, y13_6_0_exp, \
           x13_4_4_exp,x13_2_4_exp, x13_6_4_exp,x6_4_4_exp,x6_2_4_exp,x6_6_4_exp, x13_2_8_exp, x13_4_8_exp,\
           y13_4_4_exp,y13_2_4_exp, y13_6_4_exp,y6_4_4_exp,y6_2_4_exp,y6_6_4_exp, y13_2_8_exp, y13_4_8_exp


def LoadExpGap(ExpName):
    crossname = ExpName
    crossing_data = pd.read_csv(crossname)
    df_exp = pd.DataFrame(crossing_data)

    mask6_2_0 = df_exp['trial_id'] == 6
    mask6_4_0 = df_exp['trial_id'] == 4
    mask6_6_0 = df_exp['trial_id'] == 8
    mask13_2_0 = df_exp['trial_id'] == 5
    mask13_4_0 = df_exp['trial_id'] == 3
    mask13_6_0 = df_exp['trial_id'] == 7

    mask13_4_4 = df_exp['trial_id'] == 9
    mask13_2_4 = df_exp['trial_id'] == 10
    mask13_6_4 = df_exp['trial_id'] == 11
    mask6_4_4 = df_exp['trial_id'] == 12
    mask6_2_4 = df_exp['trial_id'] == 13
    mask6_6_4 = df_exp['trial_id'] == 14

    mask13_2_8 = df_exp['trial_id'] == 15
    mask13_4_8 = df_exp['trial_id'] == 16

    df_exp6_2_0 = df_exp[mask6_2_0]
    gap = []
    for i in range(df_exp6_2_0.shape[0]):
        if df_exp6_2_0['cross_time'].iloc[i] < 2.29:
            gap.append(1)
        else:
            gap.append(0)
    df_exp6_2_0['gap_acc'] = gap

    df_exp13_2_0 = df_exp[mask13_2_0]
    gap = []
    for i in range(df_exp13_2_0.shape[0]):
        if df_exp13_2_0['cross_time'].iloc[i] < 2.29:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_2_0['gap_acc'] = gap

    df_exp6_4_0 = df_exp[mask6_4_0]
    gap = []
    for i in range(df_exp6_4_0.shape[0]):
        if df_exp6_4_0['cross_time'].iloc[i] < 4.58:
            gap.append(1)
        else:
            gap.append(0)
    df_exp6_4_0['gap_acc'] = gap

    df_exp13_4_0 = df_exp[mask13_4_0]
    gap = []
    for i in range(df_exp13_4_0.shape[0]):
        if df_exp13_4_0['cross_time'].iloc[i] < 4.58:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_4_0['gap_acc'] = gap

    df_exp6_6_0 = df_exp[mask6_6_0]
    gap = []
    for i in range(df_exp6_6_0.shape[0]):
        if df_exp6_6_0['cross_time'].iloc[i] < 6.87:
            gap.append(1)
        else:
            gap.append(0)
    df_exp6_6_0['gap_acc'] = gap

    df_exp13_6_0 = df_exp[mask13_6_0]
    gap = []
    for i in range(df_exp13_6_0.shape[0]):
        if df_exp13_6_0['cross_time'].iloc[i] < 6.87:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_6_0['gap_acc'] = gap


    df_exp6_2_4 = df_exp[mask6_2_4]
    gap = []
    for i in range(df_exp6_2_4.shape[0]):
        if df_exp6_2_4['cross_time'].iloc[i] < 2.29:
            gap.append(1)
        else:
            gap.append(0)
    df_exp6_2_4['gap_acc'] = gap

    df_exp13_2_4 = df_exp[mask13_2_4]
    gap = []
    for i in range(df_exp13_2_4.shape[0]):
        if df_exp13_2_4['cross_time'].iloc[i] < 2.29:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_2_4['gap_acc'] = gap

    df_exp6_4_4 = df_exp[mask6_4_4]
    gap = []
    for i in range(df_exp6_4_4.shape[0]):
        if df_exp6_4_4['cross_time'].iloc[i] < 4.58:
            gap.append(1)
        else:
            gap.append(0)
    df_exp6_4_4['gap_acc'] = gap

    df_exp13_4_4 = df_exp[mask13_4_4]
    gap = []
    for i in range(df_exp13_4_4.shape[0]):
        if df_exp13_4_4['cross_time'].iloc[i] < 4.58:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_4_4['gap_acc'] = gap

    df_exp6_6_4 = df_exp[mask6_6_4]
    gap = []
    for i in range(df_exp6_6_4.shape[0]):
        if df_exp6_6_4['cross_time'].iloc[i] < 6.87:
            gap.append(1)
        else:
            gap.append(0)
    df_exp6_6_4['gap_acc'] = gap

    df_exp13_6_4 = df_exp[mask13_6_4]
    gap = []
    for i in range(df_exp13_6_4.shape[0]):
        if df_exp13_6_4['cross_time'].iloc[i] < 6.87:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_6_4['gap_acc'] = gap

    df_exp13_2_8 = df_exp[mask13_2_8]
    gap = []
    for i in range(df_exp13_2_8.shape[0]):
        if df_exp13_2_8['cross_time'].iloc[i] < 2.29:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_2_8['gap_acc'] = gap

    df_exp13_4_8 = df_exp[mask13_4_8]
    gap = []
    for i in range(df_exp13_4_8.shape[0]):
        if df_exp13_4_8['cross_time'].iloc[i] < 2.29:
            gap.append(1)
        else:
            gap.append(0)
    df_exp13_4_8['gap_acc'] = gap

    acc6_exp = [
        len(df_exp6_2_0['gap_acc'][df_exp6_2_0['gap_acc'] == 1]) / len(df_exp6_2_0['gap_acc']),
        len(df_exp6_4_0['gap_acc'][df_exp6_4_0['gap_acc'] == 1]) / len(df_exp6_4_0['gap_acc']),
        len(df_exp6_6_0['gap_acc'][df_exp6_6_0['gap_acc'] == 1]) / len(df_exp6_6_0['gap_acc']),
        len(df_exp6_2_4['gap_acc'][df_exp6_2_4['gap_acc'] == 1]) / len(df_exp6_2_4['gap_acc']),
        len(df_exp6_4_4['gap_acc'][df_exp6_4_4['gap_acc'] == 1]) / len(df_exp6_4_4['gap_acc']),
        len(df_exp6_6_4['gap_acc'][df_exp6_6_4['gap_acc'] == 1]) / len(df_exp6_6_4['gap_acc']),
    ]
    acc13_exp = [
        len(df_exp13_2_0['gap_acc'][df_exp13_2_0['gap_acc'] == 1]) / len(df_exp13_2_0['gap_acc']),
        len(df_exp13_4_0['gap_acc'][df_exp13_4_0['gap_acc'] == 1]) / len(df_exp13_4_0['gap_acc']),
        len(df_exp13_6_0['gap_acc'][df_exp13_6_0['gap_acc'] == 1]) / len(df_exp13_6_0['gap_acc']),
        len(df_exp13_2_4['gap_acc'][df_exp13_2_4['gap_acc'] == 1]) / len(df_exp13_2_4['gap_acc']),
        len(df_exp13_4_4['gap_acc'][df_exp13_4_4['gap_acc'] == 1]) / len(df_exp13_4_4['gap_acc']),
        len(df_exp13_6_4['gap_acc'][df_exp13_6_4['gap_acc'] == 1]) / len(df_exp13_6_4['gap_acc']),
        len(df_exp13_2_8['gap_acc'][df_exp13_2_8['gap_acc'] == 1]) / len(df_exp13_2_8['gap_acc']),
        len(df_exp13_4_8['gap_acc'][df_exp13_4_8['gap_acc'] == 1]) / len(df_exp13_4_8['gap_acc']),
    ]

    gap = [2.29, 4.58, 6.87]
    return acc6_exp, acc13_exp, gap