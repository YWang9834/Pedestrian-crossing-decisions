import numpy as np
import matplotlib.pyplot as plt
import os
import pandas as pd
import statistics
from scipy import ndimage
import statistics
import statsmodels.api as sm
os.chdir(os.path.dirname(os.path.abspath(__file__)))
print("Working directory set to:", os.getcwd())
# VIM
model_num = 0
input = 11
sim_csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
# Initialize a 10x10 array to hold the gap acceptance rates
gap_acceptance_rates = np.zeros((10, 10))
CITs = np.zeros((10, 10))

# Loop over your parameters (assuming they are in the range 0-9)
sigma_intervals = 11
sigmas = np.linspace(0, 1, sigma_intervals)
sigmas = sigmas[1:]

TTA_intervals = 11
Inverse_TTA_Coefs = np.linspace(0, 1, TTA_intervals)
Inverse_TTA_Coefs = Inverse_TTA_Coefs[1:]
Inverse_TTA_Coefs = np.flip(Inverse_TTA_Coefs)
# for sigma in sigmas:
#     for j in Inverse_TTA_Coefs:
for i in range(10):
    for j in range(10):
        k = None
        Inverse_TTA_Coef = Inverse_TTA_Coefs[i]
        Inverse_TTA_Coef = round(Inverse_TTA_Coef, 3)
        Inverse_TTA_Coef = 100 * Inverse_TTA_Coef
        sigma = sigmas[j]
        sigma = round(sigma, 3)
        # Read the file corresponding to parameters i, j
        # Replace this with your own code to read the file and get the gap acceptance rate
        csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_{input}_Test{k}.csv'

        csv_file = os.path.join(sim_csv_dir, csvname)
        df = pd.read_csv(csv_file)
        df = df[df['score'] == 1]

        acc0 = df['acceleration'] == 0
        gap_acceptance_rate = len(df['gap_accept'][acc0][df['gap_accept'][acc0] == 1]) / len(df['gap_accept'][acc0])
        # Store the gap acceptance rate in the array
        CIT = statistics.mean(df['start_time'])
        gap_acceptance_rates[i, j] = gap_acceptance_rate
        CITs[i, j] = CIT
        print(f'sigma{sigma};InverseTTA:{Inverse_TTA_Coef}; rate:{gap_acceptance_rate}; CIT:{CIT}')
# VM

# IM

# print(CITs)
param1 = np.array([round(sigma, 3) for sigma in sigmas]*10)
param2 = np.array([round(100 * Inverse_TTA_Coef, 3) for Inverse_TTA_Coef in Inverse_TTA_Coefs]*10)
output = CITs.flatten()  # Make the 2D output array 1D for correlation calculation

X = np.stack((param1, param2), axis=1)
y = output

# Add a constant (intercept term) to the predictors matrix
X = sm.add_constant(X)

# Fit the model
model = sm.OLS(y, X)
results = model.fit()

# Print out the model summary statistics
print(results.summary())

# plt.imshow(gap_acceptance_rates, cmap='hot', interpolation='nearest')
# plt.colorbar(label='Gap Acceptance Rate')
plt.figure(figsize=(10, 8))
zoom_factor = 10
# smooth_gap_acceptance_rates = ndimage.zoom(gap_acceptance_rates, zoom_factor, order=3)
rightlabel_font = 24
leftlabel_font = 16
title_font = 10
tick_size = 20
linewidth = 1.8
alpha = 0.8


im = plt.imshow(CITs, cmap='hot', interpolation='nearest')
cbar = plt.colorbar(im, label='Mean CIT (s)')
cbar.set_label('Mean CIT (s)', size=rightlabel_font)  # Change the label size here
cbar.ax.tick_params(labelsize=tick_size)
# cbar.ax.tick_params(labelsize=15)  # Change tick label size here

plt.xticks(range(10), [round(sigma, 3) for sigma in sigmas],fontsize = tick_size)
plt.yticks(range(10), [round(100 * Inverse_TTA_Coef, 3) for Inverse_TTA_Coef in Inverse_TTA_Coefs],fontsize = tick_size)
plt.xlabel( r'$\sigma_{\text{v}}$', fontsize=rightlabel_font)
plt.ylabel(r'$c$', fontsize=rightlabel_font)
# plt.title('Heatmap of Cross Initiation Time versus Sigma and Inverse TTA Coefficient')
plot_dir = 'Plot'
os.makedirs(plot_dir, exist_ok=True)
CIT_name = f'Heatmap_{model_num}.png'
CIT_Heatmap = os.path.join(plot_dir, CIT_name)
plt.savefig(CIT_Heatmap, dpi=300, bbox_inches='tight')
plt.show()

