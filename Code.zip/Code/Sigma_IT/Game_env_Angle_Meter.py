import pygame
import random
from collections import namedtuple
import numpy as np
import copy
import matplotlib.pyplot as plt

pygame.init()
font = pygame.font.Font('arial.ttf', 25)

Point = namedtuple('Point', 'x, y')

# rgb colors
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE1 = (0, 0, 255)
BLUE2 = (0, 100, 255)
BLACK = (0, 0, 0)
GREY = (128, 128, 128)
BLOCK_SIZE = 10
SPEED = 20
time_penalty_constant = 0.01
constant_speed = True

iX = 0
iV = 1
iA = 2
dt = 0.1

class KF_New:
    def __init__(self, initial_x: float,
                 initial_v: float,
                 initial_a: float,
                 a_proc_noise: float,
                 v_proc_noise: float,
                 meas_std: float,
                 init_v_std: float,
                 init_a_std: float
                 ) -> None:
        # mean of state
        self.R = None
        NUMVARS = iA + 1
        self._x = np.zeros(NUMVARS)
        # Initial state
        self._x[iX] = initial_x
        self._x[iV] = initial_v
        self._x[iA] = initial_a
        # State transition model
        # self.F = np.eye(NUMVARS)
        # self.F[iX, iV] = dt
        self.F = np.array([[1, dt, 0.5 * dt ** 2], [0, 1, dt], [0, 0, 1]])

        # Observation model
        self.Hmatrix = np.array(((1, 0, 0),))
        self.a_proc = a_proc_noise
        self.v_proc = v_proc_noise
        # Covariance matrix (Initial)
        self._P = np.array(((meas_std ** 2, 0, 0),
                            (0, init_v_std ** 2, 0),
                            (0, 0, init_a_std ** 2)))

    def predict(self):
        # x = F x
        # predicted state estimate
        new_x = self.F @ self._x
        Q = np.array(((0, 0, 0),
                      (0, self.v_proc ** 2, 0),
                      (0, 0, self.a_proc ** 2)))
        new_P = self.F.dot(self._P).dot(self.F.T) + Q
        # Prior
        self._P = new_P
        self._x = new_x

    def update(self, meas_value: float,
               meas_std: float):
        # y = z - H x
        # S = H P Ht + R
        # K = P Ht S^-1 (optimal kalman gain)
        # x = x + K y (updated state estimate)
        # P = (I - K H) * P (updated estimate cov)
        # Measurement covariance
        self.R = np.array([meas_std ** 2])
        # Measurement value
        z = np.array([meas_value])
        # Innovation (Residual)
        y = z - self.Hmatrix.dot(self._x)
        # Innovation covariance
        S = self.Hmatrix.dot(self._P).dot(self.Hmatrix.T) + self.R
        # Optimal Kalman gain
        K = self._P.dot(self.Hmatrix.T).dot(np.linalg.inv(S))
        # Updated state estimate (Posterior)
        new_x = self._x + K.dot(y)
        # Updated estimate covariance (Posterior)
        new_P = (np.eye(3) - K.dot(self.Hmatrix)).dot(self._P)
        # print(new_P)
        self._P = new_P
        self._x = new_x

    @property
    def cov(self) -> np.array:
        return self._P

    @property
    def mean(self) -> np.array:
        return self._x

    @property
    def pos(self) -> float:
        return self._x[iX]

    @property
    def vel(self) -> float:
        return self._x[iV]


class Crossing():
    def __init__(self, train, reward,constant):
        self.motor_delay = None
        self.distance = None
        self.a = None
        self.state = None
        self.w = 1500
        self.h = 400
        self.train = train
        self.r = reward
        if self.train:
            # self.gap = np.linspace(0, 7, 14)  # s
            # self.velocity = [7, 14, 16, 18]
            self.gap = [1, 1.5, 2.3, 3, 3.5, 4, 4.6, 5, 5.5, 6, 6.9]  # s
            self.velocity = [6.94, 13.89,20.84]  # m/s
            self.acc = [0, 0.55, 0.87, 1.06, 1.62, 1.73, 2.02, 3.47, 4.05]
            # for i in range(10):
            #     self.acc.append(0)
        else:
            # self.gap = [1, 2.3, 4.6, 6.9]  # s
            self.gap = [1, 1.5, 2.3, 3, 3.5, 4, 4.6, 5, 5.5, 6, 6.9]  # s
            self.velocity = [6.94, 13.89,20.84]  # m/s
            self.acc = [0, 0.55, 0.87, 1.06, 1.62, 1.73, 2.02, 3.47, 4.05]
        self.nA = 2
        self.score = None
        self.vehicle = None
        self.vehicle1 = None
        self.direction = None
        self.vehicle_direction = None
        self.v = None
        self.g = None
        self.pedestrian = None
        self.frame_iteration = None
        self.time = None
        self.t = None
        self.accept = None
        self.arrive = None
        self.collision = None
        self.cum_reward = None
        self.bottom = None
        self.middle = None
        self.px = None
        self.py = None
        self.v1x = None
        self.v1y = None
        self.uncer_1_x = None
        self.uncer_1_v = None
        self.kf1 = None
        self.x1_filtered = None
        self.v1_filtered = None
        self.sigma = None
        self.render = False
        self.stop_time = None
        self.constant = constant
        # if constant_speed == True:
        #     self.constant = True
        # else:
        #     self.constant = False
        self.delay_input = True

        if self.render:
            self.display = pygame.display.set_mode((self.w, self.h))
            pygame.display.set_caption('Crossing')
        self.clock = pygame.time.Clock()

    def gauss_noise(self, input, mu, sigma):
        mu = mu
        sigma = sigma
        input_c = copy.deepcopy(input)
        for i in range(len([input_c])):
            input_c += random.gauss(mu, sigma)
        return input_c

    def reset(self, sigma, Inverse_TTA_Coef):
        self.vehicle_direction = 0
        self.init_v = random.choice(self.velocity)
        self.v = self.init_v
        init_v_n = self.gauss_noise(self.v, 0, np.std(self.velocity))
        self.g = random.choice(self.gap)
        self.a = -random.choice(self.acc)
        init_a_n = self.gauss_noise(self.a, 0, np.std(self.acc))
        if self.constant:
            self.a = 0
        self.pedestrian = Point(295 / BLOCK_SIZE, 229.25 / BLOCK_SIZE)
        self.score = 0
        self.vehicle = None
        self.vehicle1 = None
        d_list = [15.90,31.81,47.71,63.61,95.42]
        self.distance = 0
        self.initial_position = self.g * self.v + 30
        self._place_vehicle1()
        self.frame_iteration = 0
        self.time = 0
        self.stop_time = 0

        self.t = 0
        self.accept = 0
        self.collision = 0
        self.steps = 0
        self.steplist = []
        self.noisy = []
        self.real = []
        self.filter = []
        self.steplist.append(self.steps)
        sigma_list= [ 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

        TTA_intervals = 11
        Inverse_TTAs = np.linspace(0, 1, TTA_intervals)
        Inverse_TTA_list = list(Inverse_TTAs)
        Inverse_TTA_list = Inverse_TTA_list[1:]
        Inverse_TTA_list = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

        if self.train:
            self.sigma = random.choice(sigma_list)
            self.sigma = round(self.sigma, 3)
            self.Inverse_TTA_Coef = random.choice(Inverse_TTA_list)
        else:
            self.sigma = sigma
            self.Inverse_TTA_Coef = Inverse_TTA_Coef

        # self.sigma_v = abs(np.random.normal(0, self.sigma))
        self.sigma_v = abs(self.sigma)


        Dl1 = abs(self.vehicle1.x - self.pedestrian.x)

        D1 = np.sqrt((self.pedestrian.x - self.vehicle1.x) ** 2 + (self.pedestrian.y - self.vehicle1.y) ** 2)
        self.sigma_a_1 = Dl1 * (1 - (1.6 / (D1 * np.tan(np.arctan(1.6 / D1) +self.sigma_v
                                                        ))))

        self.noisy_distance = self.gauss_noise(self.distance, 0, self.sigma_a_1)

        self.x1_noisy = self.initial_position - self.noisy_distance
        if self.constant:
            self.kf1 = KF_New(initial_x=self.noisy_distance, initial_v=init_v_n, initial_a=0, v_proc_noise=1,
                              a_proc_noise=0,
                              meas_std=self.sigma_a_1,
                              init_v_std=np.std(self.velocity), init_a_std=np.std(self.acc))
        else:
            self.kf1 = KF_New(initial_x=(self.noisy_distance), initial_v=init_v_n, initial_a=init_a_n, v_proc_noise=1,
                              a_proc_noise=0.1,
                              meas_std=self.sigma_a_1,
                              init_v_std=np.std(self.velocity), init_a_std=np.std(self.acc))
            self.a1_filtered = self.kf1.mean[2]
        self.filtered_distance = self.kf1.mean[0]
        self.x1_filtered = self.initial_position - self.filtered_distance
        self.v1_filtered = self.kf1.mean[1]
        if constant_speed == True:
            self.a1_filtered = 0
        else:
            self.a1_filtered = self.kf1.mean[2]

        self.uncer_1_x = np.sqrt(self.kf1.cov[0, 0])
        self.uncer_1_v = np.sqrt(self.kf1.cov[1, 1])
        self.arrive = 0
        self.motor_delay = random.gauss(0.6, 0.2)  # in 0.1s
        if self.motor_delay < 0:
            self.motor_delay = -self.motor_delay

        self.state = (self.pedestrian.x, self.pedestrian.y,
                      self.x1_filtered, self.vehicle1.y, self.v1_filtered,
                      self.uncer_1_x, self.uncer_1_v, self.sigma, self.Inverse_TTA_Coef, self.frame_iteration)

        self.filter.append(self.x1_filtered)
        self.real.append(self.vehicle1.x)
        self.noisy.append(self.x1_noisy)
        return np.array(self.state, dtype=np.float32)

    def _place_vehicle1(self):
        # x = self.g * self.v * 10 + 950.5 + 4.95 * BLOCK_SIZE  # gap*velocity+v1x+v1l  m*10+pixel
        x = self.initial_position - self.distance
        y = 204.875 / BLOCK_SIZE
        self.vehicle1 = Point(x, y)

    def step(self, action):
        self.frame_iteration += 1
        # 1. collect user input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        # 3. check if game over
        reward = 0
        self.score = 0
        game_over = False

        inverse_TTA_est = (self.v1_filtered) / ( self.x1_filtered -self.pedestrian.x +0.01)
        if inverse_TTA_est<=0:
            inverse_TTA_est = 0



        if action == 1:
            if self.delay_input:
                motor_delay_distance = self.motor_delay * 1.31
                x = self.pedestrian.x
                y = self.pedestrian.y
                y += motor_delay_distance
                self.pedestrian = Point(x, y)
            while not game_over:
                self.steps += 1
                self.t += 0.1
                self.move(action)  # update the head
                self.vehicle1_move(self.vehicle_direction)

                self.sigma_v = abs(self.sigma)

                Dl1 = abs(self.vehicle1.x - self.pedestrian.x)

                D1 = np.sqrt((self.pedestrian.x - self.vehicle1.x) ** 2 + (self.pedestrian.y - self.vehicle1.y) ** 2)
                self.sigma_a_1 = Dl1 * (1 - (1.6 / (D1 * np.tan(np.arctan(1.6 / D1) + self.sigma_v
                                                                ))))

                self.noisy_distance = self.gauss_noise(self.distance, 0, self.sigma_a_1)
                self.x1_noisy = self.initial_position - self.noisy_distance
                self.kf1.predict()
                self.kf1.update(self.noisy_distance, self.sigma_a_1)
                self.filtered_distance = self.kf1.mean[0]
                self.x1_filtered = self.initial_position - self.filtered_distance
                self.v1_filtered = self.kf1.mean[1]
                self.a1_filtered = self.kf1.mean[2]
                if self.render:
                    self._update_ui()
                    self.clock.tick(SPEED)

                # if self.pedestrian.x + 0.5 > self.vehicle1.x and self.pedestrian.x < self.vehicle1.x + 4.95 \
                #         and self.pedestrian.y < self.vehicle1.y + 1.95 and self.pedestrian.y + 0.5 > self.vehicle1.y:
                # safety zone
                pedestrianzone = 0.5
                if self.pedestrian.x + pedestrianzone > self.vehicle1.x and self.pedestrian.x < self.vehicle1.x + 4.95 \
                        and self.pedestrian.y < self.vehicle1.y + 1.95 and self.pedestrian.y + pedestrianzone > self.vehicle1.y:
                    self.collision = 1
                    game_over = True
                    reward -= self.r

                if self.pedestrian.y + pedestrianzone < 200 / BLOCK_SIZE:
                    reward += (self.r - self.Inverse_TTA_Coef * inverse_TTA_est-
                               time_penalty_constant * self.frame_iteration)
                    self.score = 1
                    game_over = True

                self.filter.append(self.x1_filtered)
                self.real.append(self.vehicle1.x)
                self.noisy.append(self.x1_noisy)
                # self.filter.append(self.filtered_distance)
                # self.real.append(self.distance)
                # self.noisy.append(self.noisy_distance)
                self.steplist.append(self.steps)
            #
            # if game_over == True:
            #     print(self.steplist)
            #     print(self.noisy)
            #     plt.plot(self.steplist, self.noisy, alpha=0.6, color='orange', label='Measurements')
            #     plt.plot(self.steplist, self.filter, label='Estimated position', color='grey')
            #     plt.plot(self.steplist, self.real, label='Real position')
            #     plt.legend()
            #     plt.show()

        # 2. move
        self.t += 0.1
        self.move(action)  # update the head
        self.vehicle1_move(self.vehicle_direction)

        Dl1 = abs(self.vehicle1.x - self.pedestrian.x)
        D1 = np.sqrt((self.pedestrian.x - self.vehicle1.x) ** 2 + (self.pedestrian.y - self.vehicle1.y) ** 2)


        self.sigma_a_1 = Dl1 * (1 - (1.6 / (D1 * np.tan(np.arctan(1.6 / D1) +
                                                        abs(np.random.normal(0, self.sigma))))))

        self.noisy_distance = self.gauss_noise(self.distance, 0, self.sigma_a_1)
        self.x1_noisy = self.initial_position - self.noisy_distance
        self.kf1.predict()
        self.kf1.update(self.noisy_distance, self.sigma_a_1)
        self.filtered_distance = self.kf1.mean[0]
        self.x1_filtered = self.initial_position - self.filtered_distance
        self.v1_filtered = self.kf1.mean[1]
        if constant_speed:
            self.a1_filtered = 0
        else:
            self.a1_filtered = self.kf1.mean[2]
        self.uncer_1_x = np.sqrt(self.kf1.cov[0, 0])
        self.uncer_1_v = np.sqrt(self.kf1.cov[1, 1])

        if self.vehicle_has_passed():
            reward -= self.r
            game_over = True

        if self.stop_long():
            reward -= self.r
            game_over = True

        # 6. return game over and score
        self.state = (self.pedestrian.x, self.pedestrian.y,
                      self.x1_filtered, self.vehicle1.y, self.v1_filtered,
                      self.uncer_1_x, self.uncer_1_v, self.sigma, self.Inverse_TTA_Coef,
                      self.frame_iteration)
        # return reward, game_over, self.score
        self.time = self.frame_iteration / 10
        self.filter.append(self.x1_filtered)
        self.real.append(self.vehicle1.x)
        self.noisy.append(self.x1_noisy)
        self.steps += 1

        self.steplist.append(self.steps)
        if reward > self.r:
            reward = self.r
        if reward < -self.r:
            reward = -self.r
        return np.array(
            self.state), reward, game_over, self.score, self.accept, self.collision, self.time, self.motor_delay, self.Inverse_TTA_Coef * inverse_TTA_est

    def is_arrived(self):
        if self.pedestrian.y + 0.5 < 170.75 / BLOCK_SIZE:
            return True

    def vehicle_has_passed(self):
        if self.vehicle1.x < -500 / BLOCK_SIZE:
            return True

    def stop_long(self):
        if self.stop_time > 50 and self.a != 0:
            return True

    def _update_ui(self):
        self.display.fill(BLACK)
        pygame.draw.rect(self.display, WHITE,
                         pygame.Rect(0, 170.75, 1500, 1.25))
        pygame.draw.rect(self.display, WHITE,
                         pygame.Rect(0, 229.25, 1500, 1.25))
        pygame.draw.rect(self.display, GREY,
                         pygame.Rect(0, 200, 1600, 1.25))
        pygame.draw.rect(self.display, BLUE1,
                         pygame.Rect(self.pedestrian.x * BLOCK_SIZE, self.pedestrian.y * BLOCK_SIZE, 0.5 * BLOCK_SIZE,
                                     0.5 * BLOCK_SIZE))
        pygame.draw.rect(self.display, RED,
                         pygame.Rect(self.vehicle1.x * BLOCK_SIZE, self.vehicle1.y * BLOCK_SIZE, 4.95 * BLOCK_SIZE,
                                     1.95 * BLOCK_SIZE))

        # print the filtered vehicle
        pygame.draw.rect(self.display, WHITE,
                         pygame.Rect((self.initial_position - self.filtered_distance) * BLOCK_SIZE,
                                     self.vehicle1.y * BLOCK_SIZE, 4.95 * BLOCK_SIZE,
                                     1.95 * BLOCK_SIZE))
        # print the noisy vehicle
        pygame.draw.rect(self.display, GREY,
                         pygame.Rect((self.initial_position - self.noisy_distance) * BLOCK_SIZE,
                                     self.vehicle1.y * BLOCK_SIZE,
                                     4.95 * BLOCK_SIZE,
                                     1.95 * BLOCK_SIZE))

        # pygame.draw.rect(self.display, RED,
        #                  pygame.Rect(self.vehicle2.x, self.vehicle2.y, 4.95 * BLOCK_SIZE, 1.95 * BLOCK_SIZE))
        pygame.display.flip()

    def move(self, action):
        x = self.pedestrian.x
        y = self.pedestrian.y
        if action == 1:
            y -= 1.31 * 0.1
        elif action == 0:
            y = y
        self.pedestrian = Point(x, y)

    def vehicle1_move(self, vehicle_direction):
        y = self.vehicle1.y
        if self.v >= 0:
            self.distance = self.init_v * self.t + (self.a * self.t * self.t) / 2
            self.v = self.init_v + self.a * self.t
        else:
            self.distance = self.distance
            self.v = self.v
            self.stop_time += 1
        x = self.initial_position - self.distance
        self.vehicle1 = Point(x, y)
