import os
import numpy as np
from Dueling_DDQN_agent import Agent
from Dueling_DDQN_agent import DuelingDeepQNetwork
import pandas as pd
# from Game_env_button import Crossing
import datetime
import multiprocessing as mp
from multiprocessing import Pool

train = True
Angle = True


MultipleTrain = False
# constant = True
if Angle:
    from Game_env_Angle_Meter import Crossing




def train(agent, game, model_num, input, Train_num, sigma, Inverse_TTA_Coef, num, constant):
    # csv_dir = f'Sim_data_{model_num}_Delay'
    if constant:
        csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay'
    else:
        csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
    os.makedirs(csv_dir, exist_ok=True)
    # csvname = f'Sigma_{sigma}_Input_{input}_Train.csv'
    csvname = f'Sigma_Input_{input}_Train{num}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    scores = []
    rewards = []
    collision_rate = []
    collision_cum = 0  # cumulated collisions
    time_gap = []
    speed = []
    acceleration = []
    start_time = []
    gap_accept = []
    collisions = []
    epsilons = []
    avg_score = 0
    cum_rewards = []
    motor_delays = []
    x = []
    episode = 0
    episodes = []
    AddInfo = []

    for i in range(Train_num):

        # while avg_score < 0.98 or agent.epsilon > 0.001 or\
        #         (np.mean(rewards[max(-i, -100):]) - np.mean(rewards[max(-i, -200):max(-i, -100)])) < 1:
        episode += 1
        episodes.append(episode)
        done = False
        observation = game.reset(sigma, Inverse_TTA_Coef)
        score = 0
        go = []
        v = game.v
        g = game.g
        a = -game.a
        acceleration.append(a)
        frame = 0
        cum_reward = 0
        while not done:
            frame += 1
            action = agent.choose_action(observation)
            observation_, reward, done, score, accept, collision, decision_time, motor_delay, addinfo = game.step(
                action)
            cum_reward += reward
            agent.store_transition(observation, action, reward, observation_, int(done))
            agent.learn()
            observation = observation_
            collision_cum += collision
            reaction_time = decision_time + motor_delay

            if action == 1:
                go.append(reaction_time)
            if score == 1 and reaction_time < g:
                accept = 1

        time_gap.append(g)
        speed.append(v)
        if len(go) > 0:
            start_time.append(go[0])
        else:
            start_time.append(0)

        epsilons.append(agent.epsilon)
        if accept == 1:
            gap_accept.append(1)
        else:
            gap_accept.append(0)
        if collision == 1:
            collisions.append(1)
        else:
            collisions.append(0)
        AddInfo.append(addinfo)
        collision_rate.append(collision_cum / (i + 1))
        rewards.append(reward)  # REWARD AT THE LAST TIME STEP
        scores.append(score)
        avg_score = np.mean(scores[max(0, i - 100):(i + 1)])
        avg_reward_100 = np.mean(rewards[max(0, i - 100):(i + 1)])
        cum_rewards.append(cum_reward)
        motor_delays.append(motor_delay)

        if i > 0 and i % 2000 == 0:
            print('episode:%.2f' % i,
                  'score:%.2f' % score,
                  'reward:%.2f' % reward,
                  'cum_reward/episode:%.2f' % cum_reward,
                  'average_reward_100:%.2f' % avg_reward_100,
                  'average_score:%.2f' % avg_score,
                  'epsilon:%.2f' % agent.epsilon,
                  'InverseTTA:%.2f' % addinfo)
            agent.save_models()

        # eps_history.append(agent.epsilon)
        i += 1

    # x = [iterations + 1 for iterations in range(i)]
    data = {'time_gap': time_gap,
            'speed': speed,
            'acceleration': acceleration,
            'start_time': start_time,
            'gap_accept': gap_accept,
            'epsilon': epsilons,
            'collision': collisions,
            'episode': episodes,
            'score': scores,
            'reward': rewards,
            'cum_reward': cum_rewards,
            'motor_delay': motor_delays,
            'AddInfo': AddInfo}
    df = pd.DataFrame(data)
    df = df.set_index('episode')
    df.to_csv(csv_file)
    agent.save_models()


def test(agent, game, model_num, input, Test_num, sigma, Inverse_TTA_Coef, num, constant):
    if constant:
        csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay'
    else:
        csv_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
    os.makedirs(csv_dir, exist_ok=True)
    csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_{input}_Test{num}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    scores = []
    rewards = []
    eps_history = []
    collision_rate = []
    collision_cum = 0  # cumulated collisions
    time_gap = []
    speed = []
    acceleration = []
    start_time = []
    bottom_time = []
    middle_time = []
    gap_accept = []
    collisions = []
    epsilons = []
    avg_score = 0
    cum_rewards = []
    motor_delays = []
    episode = 0
    episodes = []
    AddInfo = []

    for i in range(Test_num):
        episode += 1
        episodes.append(episode)
        done = False
        observation = game.reset(sigma, Inverse_TTA_Coef)
        score = 0
        go = []
        bottom = []
        middle = []
        v = game.v
        g = game.g
        a = -game.a
        frame = 0
        cum_reward = 0
        while not done:
            frame += 1
            action = agent.choose_action(observation)
            observation_, reward, done, score, accept, collision, decision_time, motor_delay, addinfo = game.step(
                action)
            cum_reward += reward
            observation = observation_
            collision_cum += collision
            reaction_time = decision_time + motor_delay

            if action == 1:
                # go.append(decision_time)
                go.append(reaction_time)

            # if score == 1 and decision_time < g:
            if score == 1 and reaction_time < g:
                accept = 1
        time_gap.append(g)
        speed.append(v)
        acceleration.append(a)

        if len(go) > 0:
            start_time.append(go[0])
        else:
            start_time.append(0)

        # if len(bottom) > 0:
        #     bottom_time.append(bottom[0])
        # else:
        #     bottom_time.append(0)
        #
        # if len(middle) > 0:
        #     middle_time.append(middle[0])
        # else:
        #     middle_time.append(0)
        epsilons.append(agent.epsilon)
        if accept == 1:
            gap_accept.append(1)
        else:
            gap_accept.append(0)
        if collision == 1:
            collisions.append(1)
        else:
            collisions.append(0)

        collision_rate.append(collision_cum / (i + 1))

        AddInfo.append(addinfo)
        rewards.append(reward)
        scores.append(score)
        avg_score = np.mean(scores[max(0, i - 100):(i + 1)])
        avg_reward_100 = np.mean(rewards[max(0, i - 100):(i + 1)])
        cum_rewards.append(cum_reward)
        motor_delays.append(motor_delay)
        print('episode:%.2f' % i,
              'score:%.2f' % score,
              'reward:%.2f' % reward,
              'cum_reward/episode:%.2f' % cum_reward,
              'average_reward_100:%.2f' % avg_reward_100,
              'average_score:%.2f' % avg_score,
              'epsilon:%.2f' % agent.epsilon,
              'InverseTTA:%.2f' % addinfo)

        eps_history.append(agent.epsilon)
    x = [i + 1 for i in range(Test_num)]
    print(
        f'time_gap:{len(time_gap)}; speed: {len(speed)}; acceleration: {len(acceleration)}; cross_time: {len(start_time)};'
        f' acc:{len(gap_accept)}; epsilon: {len(epsilons)}; col:{len(collisions)}; epi:{len(x)};'
        f' reward:{len(rewards)}; score:{len(scores)}')
    data = {'time_gap': time_gap,
            'speed': speed,
            'acceleration': acceleration,
            'start_time': start_time,
            'gap_accept': gap_accept,
            'epsilon': epsilons,
            'collision': collisions,
            'episode': episodes,
            'score': scores,
            'reward': rewards,
            'cum_reward': cum_rewards,
            'motor_delay': motor_delays,
            'AddInfo': AddInfo}
    df = pd.DataFrame(data)
    df = df.set_index('episode')
    df.to_csv(csv_file)


# def MultiTraining():
#     if MultipleTrain:
#         for i in range(10):
#             i += 1
#             starttime = datetime.datetime.now()
#             # Train
#             game = Crossing(train=True)
#             sigma = None
#             Inverse_TTA_Coef = None
#             agent = Agent(gamma=0.99, epsilon=1, lr=0.0001,
#                           input_dims=[input], n_actions=2, mem_size=100000,
#                           batch_size=64, eps_min=0.001, eps_dec=1e-4, replace=1000, input=input, model_num=model_num,
#                           sigma=sigma, constant=game.constant)
#             train(agent, sigma, Inverse_TTA_Coef, i)
#             # Test
#             intervals = 11
#             sigmas = np.linspace(0, 1, intervals)
#             sigmas = sigmas[1:]
#             Inverse_TTA_Coefs = np.linspace(0, 1, intervals)
#             Inverse_TTA_Coefs = Inverse_TTA_Coefs[1:]
#             for sigma in sigmas:
#                 # game = Crossing(train=True)
#                 sigma = round(sigma, 3)
#                 for Inverse_TTA_Coef in Inverse_TTA_Coefs:
#                     Inverse_TTA_Coef = round(Inverse_TTA_Coef, 3)
#                     Inverse_TTA_Coef = 100 * Inverse_TTA_Coef
#                     print(f'sigma:{sigma}; Inverse_TTA_Coef: {Inverse_TTA_Coef}')
#                     game = Crossing(train=False)
#                     agent = Agent(gamma=0.99, epsilon=0, lr=0.0001,
#                                   input_dims=[input], n_actions=2, mem_size=100000,
#                                   batch_size=64, eps_min=0, eps_dec=1e-4, replace=1000, input=input,
#                                   model_num=model_num,
#                                   sigma=sigma, constant=game.constant)
#                     agent.load_models()
#                     test(agent, Test_num, sigma, Inverse_TTA_Coef, i)
#             endtime = datetime.datetime.now()
#             print(endtime - starttime)

def SingleTraining(ModelNum, InputNum, reward, constant, TrainNum, TestNum):
    model_num = ModelNum
    input = InputNum

    i = None
    starttime = datetime.datetime.now()
    # Train
    game = Crossing(train=True, reward=reward, constant=constant)
    sigma = None
    Inverse_TTA_Coef = None
    agent = Agent(gamma=0.99, epsilon=1, lr=0.0001,
                  input_dims=[input], n_actions=2, mem_size=100000,
                  batch_size=64, eps_min=0.001, eps_dec=5e-5, replace=1000, input=input, model_num=model_num,
                  sigma=sigma, constant=game.constant)
    train(agent=agent, Train_num=TrainNum, input=input, model_num=ModelNum, game=game, sigma=sigma,
          Inverse_TTA_Coef=Inverse_TTA_Coef, num=i, constant=constant)
    # Test
    sigma_intervals = 11
    TTA_intervals = 11
    sigmas = np.linspace(0, 1, sigma_intervals)
    sigmas = sigmas[1:]
    Inverse_TTA_Coefs = np.linspace(0, 1, TTA_intervals)
    Inverse_TTA_Coefs = Inverse_TTA_Coefs[1:]
    # store model info
    if constant:
        info_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay'
    else:
        info_dir = f'../Sim_Data/DQN_Sigma_IT_Input/Sim_data_{model_num}_Delay_Dec'
    os.makedirs(info_dir, exist_ok=True)
    infoname = f'Info_{model_num}.csv'
    info_file = os.path.join(info_dir, infoname)
    data = {'reward': reward, 'sigma': sigmas}
    df = pd.DataFrame(data)
    df.to_csv(info_file)
    for sigma in sigmas:
        sigma = round(sigma, 3)
        for Inverse_TTA_Coef in Inverse_TTA_Coefs:
            Inverse_TTA_Coef = round(Inverse_TTA_Coef, 3)
            Inverse_TTA_Coef = 100 * Inverse_TTA_Coef
            print(f'sigma:{sigma}; Inverse_TTA_Coef: {Inverse_TTA_Coef}')
            game = Crossing(train=False, reward=reward, constant=constant)
            agent = Agent(gamma=0.99, epsilon=0, lr=0.0001,
                          input_dims=[input], n_actions=2, mem_size=100000,
                          batch_size=64, eps_min=0, eps_dec=5e-5, replace=1000, input=input,
                          model_num=model_num,
                          sigma=sigma, constant=game.constant)
            agent.load_models()
            test(agent=agent, game=game, Test_num=TestNum, model_num=ModelNum, input=input, sigma=sigma,
                 Inverse_TTA_Coef=Inverse_TTA_Coef, num=i, constant=constant)
    endtime = datetime.datetime.now()
    print(endtime - starttime)


def worker(task):
    SingleTraining(*task)


if __name__ == '__main__':

    ModelNum1 = 0

    InputNum1 = 10
    reward1 = 20

    constant1 = False
    constant2 = True
    Train_num1 = 45000
    Test_num1 = 2500


    tasks = [(ModelNum1, InputNum1, reward1, constant1, Train_num1, Test_num1)
             # Add as many as you need
             ]
    # worker(tasks)
    with Pool(processes=mp.cpu_count() - 4) as pool:
        pool.map(worker, tasks)
