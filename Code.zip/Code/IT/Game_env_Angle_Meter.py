import pygame
import random
from collections import namedtuple
import numpy as np
import copy
import matplotlib.pyplot as plt

pygame.init()
font = pygame.font.Font('arial.ttf', 25)

Point = namedtuple('Point', 'x, y')

# rgb colors
WHITE = (255, 255, 255)
RED = (200, 0, 0)
BLUE1 = (0, 0, 255)
BLUE2 = (0, 100, 255)
BLACK = (0, 0, 0)
GREY = (128, 128, 128)
BLOCK_SIZE = 10
SPEED = 20
time_penalty_constant = 0.01
# inverse_TTA_constant = 80
constant_speed = False

iX = 0
iV = 1
iA = 2
dt = 0.1

class Crossing():
    def __init__(self, train, reward,constant):
        self.motor_delay = None
        self.distance = None
        self.a = None
        self.state = None
        self.w = 1500
        self.h = 400
        self.train = train
        self.r = reward
        if self.train:
            self.gap = [1, 1.5, 2.3, 3, 3.5, 4, 4.6, 5, 5.5, 6, 6.9]  # s
            self.velocity = [6.94, 13.89, 20.84]  # m/s
            self.acc = [0, 0.55, 0.87, 1.06, 1.62, 1.73, 2.02, 3.47, 4.05]
        else:
            self.gap = [1, 1.5, 2.3, 3, 3.5, 4, 4.6, 5, 5.5, 6, 6.9]  # s
            self.velocity = [6.94, 13.89, 20.84]  # m/s
            self.acc = [0, 0.55, 0.87, 1.06, 1.62, 1.73, 2.02, 3.47, 4.05]
        self.nA = 2
        self.score = None
        self.vehicle = None
        self.vehicle1 = None
        self.direction = None
        self.vehicle_direction = None
        self.v = None
        self.g = None
        self.pedestrian = None
        self.frame_iteration = None
        self.time = None
        self.t = None
        self.accept = None
        self.arrive = None
        self.collision = None
        self.cum_reward = None
        self.bottom = None
        self.middle = None
        self.px = None
        self.py = None
        self.v1x = None
        self.v1y = None
        self.uncer_1_x = None
        self.uncer_1_v = None
        self.kf1 = None
        self.x1_filtered = None
        self.v1_filtered = None
        self.sigma = None
        self.render = False
        self.stop_time = None
        self.constant = constant
        self.delay_input = False


        if self.render:
            self.display = pygame.display.set_mode((self.w, self.h))
            pygame.display.set_caption('Crossing')
        self.clock = pygame.time.Clock()

    def reset(self, Inverse_TTA_Coef):
        self.vehicle_direction = 0
        self.init_v= random.choice(self.velocity)
        self.v = self.init_v
        self.g = random.choice(self.gap)
        self.a = -random.choice(self.acc)
        if self.constant:
            self.a = 0
        self.pedestrian = Point(295 / BLOCK_SIZE, 229.25 / BLOCK_SIZE)
        self.score = 0
        self.vehicle = None
        self.vehicle1 = None
        self.distance = 0
        self.initial_position = self.g * self.v + 30
        self._place_vehicle1()
        self.frame_iteration = 0
        self.time = 0
        self.stop_time = 0
        self.t = 0
        self.accept = 0
        self.collision = 0
        self.steps = 0
        self.steplist = []
        self.steplist.append(self.steps)
        self.arrive = 0

        TTA_intervals = 11
        Inverse_TTAs = np.linspace(0, 1, TTA_intervals)
        Inverse_TTA_list = list(Inverse_TTAs)
        Inverse_TTA_list = Inverse_TTA_list[1:]

        if self.train:
            self.Inverse_TTA_Coef = random.choice(Inverse_TTA_list)
            self.Inverse_TTA_Coef = round(self.Inverse_TTA_Coef,3)
            self.Inverse_TTA_Coef = 100 * self.Inverse_TTA_Coef
        else:

            self.Inverse_TTA_Coef = Inverse_TTA_Coef
        self.motor_delay = random.gauss(0.6, 0.2)  # in 0.1s
        if self.motor_delay < 0:
            self.motor_delay = -self.motor_delay
        if self.delay_input:
            self.state = (self.pedestrian.x, self.pedestrian.y, self.vehicle1.x, self.vehicle1.y, self.v,self.a,
                          self.Inverse_TTA_Coef,self.motor_delay)
        else:
            self.state = (self.pedestrian.x, self.pedestrian.y, self.vehicle1.x, self.vehicle1.y, self.v,self.a,
                          self.Inverse_TTA_Coef,self.frame_iteration)
        return np.array(self.state, dtype=np.float32)

    def _place_vehicle1(self):
        x = self.initial_position - self.distance
        y = 204.875 / BLOCK_SIZE
        self.vehicle1 = Point(x, y)

    def step(self, action):
        self.frame_iteration += 1
        # 1. collect user input
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                quit()

        # 3. check if game over
        reward = 0
        self.score = 0
        game_over = False
        Inverse_TTA_TRUE = self.v / (self.vehicle1.x - self.pedestrian.x+0.01)
        if Inverse_TTA_TRUE <= 0:
            Inverse_TTA_TRUE = 0

        if action == 1:
            if self.delay_input:
                motor_delay_distance = self.motor_delay * 1.31
                x = self.pedestrian.x
                y = self.pedestrian.y
                y += motor_delay_distance
                self.pedestrian = Point(x, y)

            while not game_over:
                self.steps += 1
                self.t += 0.1
                self.move(action)  # update the head
                self.vehicle1_move(self.vehicle_direction)

                if self.render:
                    self._update_ui()
                    self.clock.tick(SPEED)


                # safety zone
                pedestrianzone = 0.5
                if self.pedestrian.x + pedestrianzone > self.vehicle1.x and self.pedestrian.x < self.vehicle1.x + 4.95 \
                        and self.pedestrian.y < self.vehicle1.y + 1.95 and self.pedestrian.y + pedestrianzone > self.vehicle1.y:
                    self.collision = 1
                    game_over = True
                    reward -= self.r

                if self.pedestrian.y + 0.5 < 204.875 / BLOCK_SIZE:
                    reward += (self.r - self.Inverse_TTA_Coef * Inverse_TTA_TRUE -
                               time_penalty_constant * self.frame_iteration)
                    self.score = 1
                    game_over = True
                self.steplist.append(self.steps)

        # 2. move
        self.t += 0.1
        self.move(action)  # update the head
        self.vehicle1_move(self.vehicle_direction)

        if self.vehicle_has_passed():
            reward -= self.r
            game_over = True

        if self.stop_long():
            reward -= self.r
            game_over = True
        # 6. return game over and score
        if self.delay_input:
            self.state = (self.pedestrian.x, self.pedestrian.y, self.vehicle1.x, self.vehicle1.y, self.v,self.a,
                          self.Inverse_TTA_Coef,self.motor_delay,self.frame_iteration)
        else:
            self.state = (self.pedestrian.x, self.pedestrian.y, self.vehicle1.x, self.vehicle1.y, self.v, self.a,
                          self.Inverse_TTA_Coef, self.frame_iteration)

        self.time = self.frame_iteration / 10
        self.steps += 1

        self.steplist.append(self.steps)
        if reward >self.r:
            reward = self.r
        if reward<-self.r:
            reward = -self.r
        return np.array(
            self.state), reward, game_over, self.score, self.accept, self.collision, self.time, self.motor_delay, self.Inverse_TTA_Coef*Inverse_TTA_TRUE

    def is_arrived(self):
        if self.pedestrian.y + 0.5 < 170.75 / BLOCK_SIZE:
            return True

    def vehicle_has_passed(self):
        if self.vehicle1.x < -500 / BLOCK_SIZE:
            return True

    def stop_long(self):
        if self.stop_time > 50 and self.a != 0:
            return True

    def _update_ui(self):
        self.display.fill(BLACK)
        pygame.draw.rect(self.display, WHITE,
                         pygame.Rect(0, 170.75, 1500, 1.25))
        pygame.draw.rect(self.display, WHITE,
                         pygame.Rect(0, 229.25, 1500, 1.25))
        pygame.draw.rect(self.display, GREY,
                         pygame.Rect(0, 200, 1600, 1.25))
        pygame.draw.rect(self.display, BLUE1,
                         pygame.Rect(self.pedestrian.x * BLOCK_SIZE, self.pedestrian.y * BLOCK_SIZE, 0.5 * BLOCK_SIZE,
                                     0.5 * BLOCK_SIZE))
        pygame.draw.rect(self.display, RED,
                         pygame.Rect(self.vehicle1.x * BLOCK_SIZE, self.vehicle1.y * BLOCK_SIZE, 4.95 * BLOCK_SIZE,
                                     1.95 * BLOCK_SIZE))

        pygame.display.flip()

    def move(self, action):
        x = self.pedestrian.x
        y = self.pedestrian.y
        if action == 1:
            y -= 1.31 * 0.1
        elif action == 0:
            y = y
        self.pedestrian = Point(x, y)

    def vehicle1_move(self, vehicle_direction):
        y = self.vehicle1.y
        if self.v >= 0:
            self.distance = self.init_v * self.t + (self.a * self.t * self.t) / 2
            self.v = self.init_v + self.a * self.t
        else:
            self.distance = self.distance
            self.v = self.v
            self.stop_time += 1
        x = self.initial_position - self.distance
        self.vehicle1 = Point(x, y)
