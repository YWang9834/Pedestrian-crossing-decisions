import matplotlib.pyplot as plt
import numpy as np
import gym
from matplotlib.gridspec import GridSpec
import pandas as pd
import os
import seaborn as sns
MultipleFiles = False
SeperatePlot = False
model_num = 7
input = 10
sigma_file = f'./ID_Sigma/ID_Sigma_{model_num}_Dec.csv'
df_sigma = pd.read_csv(sigma_file)
sigma_list = df_sigma['Sigma'].round(3).tolist()


df_all = pd.DataFrame()
print(len(df_sigma))
csv_dir = f'../Sim_Data/DQN_Sigma_Input/Sim_data_{model_num}_Delay_Dec'
for i in range(len(df_sigma)):
    sigma = sigma_list[i]


    k = None
    csvname = f'Sigma_{sigma}_Input_{input}_Test{k}.csv'
    # csvname = f'Sigma_{sigma}_InverseTTA_{Inverse_TTA_Coef}_Input_<built-in function input>_Test{k}.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df = pd.read_csv(csv_file)
    df_all = pd.concat([df_all,df],ignore_index=True)
    print(f'sigma:{sigma};csvname:{csv_file}')
print(df_all)
def SimMean():
    df = df_all
    # df = df.dropna(axis=0)
    df = df[df['score'] == 1]

    gap10 = df['time_gap'] == 1
    gap15 = df['time_gap'] == 1.5
    gap23 = df['time_gap'] == 2.3
    gap35 = df['time_gap'] == 3.5
    gap46 = df['time_gap'] == 4.6
    gap55 = df['time_gap'] == 5.5
    gap69 = df['time_gap'] == 6.9

    speed25 = df['speed'] == 6.94
    speed30 = df['speed'] == 13.89
    speed35 = df['speed'] == 15.65
    acc0 = df['acceleration'] == 0
    acc1 = df['acceleration'] == 2.02
    acc2 = df['acceleration'] == 3.47
    acc3 = df['acceleration'] == 4.05
    acc4 = df['acceleration'] == 0.87
    acc5 = df['acceleration'] == 1.62
    acc6 = df['acceleration'] == 1.73
    acc7 = df['acceleration'] == 0.55
    acc8 = df['acceleration'] == 1.06


    start6_2 = df['start_time'][speed25][gap23][acc0].tolist()
    start6_2.sort()
    start6_4 = df['start_time'][speed25][gap46][acc0].tolist()
    start6_4.sort()
    start6_6 = df['start_time'][speed25][gap69][acc0].tolist()
    start6_6.sort()
    start13_2 = df['start_time'][speed30][gap23][acc0].tolist()
    start13_2.sort()
    start13_4 = df['start_time'][speed30][gap46][acc0].tolist()
    start13_4.sort()
    start13_6 = df['start_time'][speed30][gap69][acc0].tolist()
    start13_6.sort()

    start6_2_4 = df['start_time'][speed25][gap23][acc1].tolist()
    start6_2_4.sort()
    start13_2_4 = df['start_time'][speed30][gap23][acc2].tolist()
    start13_2_4.sort()
    start13_2_8 = df['start_time'][speed30][gap23][acc3].tolist()
    start13_2_8.sort()
    start6_4_4 = df['start_time'][speed25][gap46][acc4].tolist()
    start6_4_4.sort()
    start13_4_4 = df['start_time'][speed30][gap46][acc5].tolist()
    start13_4_4.sort()
    start13_4_8 = df['start_time'][speed30][gap46][acc6].tolist()
    start13_4_8.sort()
    start6_6_4 = df['start_time'][speed25][gap69][acc7].tolist()
    start6_6_4.sort()
    start13_6_4 = df['start_time'][speed30][gap69][acc8].tolist()
    start13_6_4.sort()
    mean_constant = [np.mean(start6_2),np.mean(start6_4),np.mean(start6_6),np.mean(start13_2),np.mean(start13_4),np.mean(start13_6)]
    mean_deceleration = [np.mean(start6_2_4),np.mean(start13_2_4),np.mean(start13_2_8),np.mean(start6_4_4),
                         np.mean(start13_4_4),np.mean(start13_4_8),np.mean(start6_6_4),np.mean(start13_6_4)]
    return mean_constant,mean_deceleration
def ExpMean():
    path = "./Exp_data"
    ExpName = path + '/d2p_cross_times_uk.csv'

    crossing_data = pd.read_csv(ExpName)
    df_exp = pd.DataFrame(crossing_data)

    mask6_2_0 = df_exp['trial_id'] == 6
    mask6_4_0 = df_exp['trial_id'] == 4
    mask6_6_0 = df_exp['trial_id'] == 8
    mask13_2_0 = df_exp['trial_id'] == 5
    mask13_4_0 = df_exp['trial_id'] == 3
    mask13_6_0 = df_exp['trial_id'] == 7

    mask13_4_4 = df_exp['trial_id'] == 9
    mask13_2_4 = df_exp['trial_id'] == 10
    mask13_6_4 = df_exp['trial_id'] == 11
    mask6_4_4 = df_exp['trial_id'] == 12
    mask6_2_4 = df_exp['trial_id'] == 13
    mask6_6_4 = df_exp['trial_id'] == 14

    mask13_2_8 = df_exp['trial_id'] == 15
    mask13_4_8 = df_exp['trial_id'] == 16

    start6_2_EXP = df_exp[mask6_2_0]['cross_time'].tolist()
    start6_2_EXP.sort()
    start6_4_EXP = df_exp[mask6_4_0]['cross_time'].tolist()
    start6_4_EXP.sort()
    start6_6_EXP = df_exp[mask6_6_0]['cross_time'].tolist()
    start6_6_EXP.sort()
    start13_2_EXP = df_exp[mask13_2_0]['cross_time'].tolist()
    start13_2_EXP.sort()
    start13_4_EXP = df_exp[mask13_4_0]['cross_time'].tolist()
    start13_4_EXP.sort()
    start13_6_EXP = df_exp[mask13_6_0]['cross_time'].tolist()
    start13_6_EXP.sort()
    start13_4_4_EXP = df_exp[mask13_4_4]['cross_time'].tolist()
    start13_4_4_EXP.sort()
    start13_2_4_EXP = df_exp[mask13_2_4]['cross_time'].tolist()
    start13_2_4_EXP.sort()
    start13_6_4_EXP = df_exp[mask13_6_4]['cross_time'].tolist()
    start13_6_4_EXP.sort()
    start6_4_4_EXP = df_exp[mask6_4_4]['cross_time'].tolist()
    start6_4_4_EXP.sort()
    start6_2_4_EXP = df_exp[mask6_2_4]['cross_time'].tolist()
    start6_2_4_EXP.sort()
    start6_6_4_EXP = df_exp[mask6_6_4]['cross_time'].tolist()
    start6_6_4_EXP.sort()
    start13_2_8_EXP = df_exp[mask13_2_8]['cross_time'].tolist()
    start13_2_8_EXP.sort()
    start13_4_8_EXP = df_exp[mask13_4_8]['cross_time'].tolist()
    start13_4_8_EXP.sort()
    mean_constant = [np.mean(start6_2_EXP),np.mean(start6_4_EXP),np.mean(start6_6_EXP),np.mean(start13_2_EXP),
                     np.mean(start13_4_EXP),np.mean(start13_6_EXP)]
    mean_deceleration = [np.mean(start6_2_4_EXP),np.mean(start13_2_4_EXP),np.mean(start13_2_8_EXP),np.mean(start6_4_4_EXP),
                         np.mean(start13_4_4_EXP),np.mean(start13_4_8_EXP),np.mean(start6_6_4_EXP),np.mean(start13_6_4_EXP)]
    return mean_constant,mean_deceleration

def calculate_mad(simulation_values, experiment_values):
    """Calculate Mean Absolute Deviation (MAD) between simulation and experiment values."""
    differences = np.abs(np.array(simulation_values) - np.array(experiment_values))
    return np.mean(differences)
if __name__ == '__main__':
    Sim_mean_constant, Sim_mean_deceleration = SimMean()
    print(Sim_mean_constant,Sim_mean_deceleration)
    Exp_mean_constant, Exp_mean_deceleration = ExpMean()
    plt.figure(figsize=(5, 5))
    plt.scatter(Sim_mean_constant, Exp_mean_constant,c='green', label='Constant')
    plt.scatter(Sim_mean_deceleration, Exp_mean_deceleration,c='orange', label='Deceleration')
    plt.xlabel('Mean predicted cross time (s)')
    plt.ylabel('Mean observed cross time (s)')
    # plt.title('Scatter plot of InverseTTA_Coef vs Sigma')
    lims = 5
    plt.xlim(0,lims)
    plt.ylim(0,lims)

    plt.plot([0,5],[0,5], 'k',linestyle='--', alpha=0.75)
    plt.legend()
    # plt.grid(True)

    MAD_constant = calculate_mad(Sim_mean_constant, Exp_mean_constant)
    MAD_deceleration = calculate_mad(Sim_mean_deceleration, Exp_mean_deceleration)
    MAD_overall = calculate_mad(Sim_mean_constant + Sim_mean_deceleration, Exp_mean_constant + Exp_mean_deceleration)

    print("MAD (Constant):", MAD_constant)
    print("MAD (Deceleration):", MAD_deceleration)
    print("MAD (Overall):", MAD_overall)
    plt.text(4.8, 0.6, f"MAD (Constant): {MAD_constant:.2f} s", ha='right')
    plt.text(4.8, 0.4, f"MAD (Deceleration): {MAD_deceleration:.2f} s", ha='right')
    plt.text(4.8, 0.2, f"MAD (Overall): {MAD_overall:.2f} s", ha='right')
    plot_dir = 'Plot'
    name = f'Dec_MAD_{model_num}.png'

    PlotName = os.path.join(plot_dir, name)
    plt.savefig(PlotName, dpi=300, bbox_inches='tight')
    plt.show()
