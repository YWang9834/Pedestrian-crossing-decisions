import pandas as pd
import numpy as np
import seaborn as sns
import os
import matplotlib.pyplot as plt
import bisect
import datetime
import statistics
from sklearn.neighbors import KernelDensity
MultipleFiles = False


starttime1 = datetime.datetime.now()
path = "./Exp_data"
crossname = path + '/d2p_cross_times_uk.csv'
crossing_data = pd.read_csv(crossname)
df = pd.DataFrame(crossing_data)
model_num = 0
input = 10

mask6_2 = df['trial_id'] == 6
mask6_4 = df['trial_id'] == 4
mask6_6 = df['trial_id'] == 8

mask13_2 = df['trial_id'] == 5
mask13_4 = df['trial_id'] == 3
mask13_6 = df['trial_id'] == 7

mask6_2_0 = df['trial_id'] == 6
mask6_4_0 = df['trial_id'] == 4
mask6_6_0 = df['trial_id'] == 8
mask13_2_0 = df['trial_id'] == 5
mask13_4_0 = df['trial_id'] == 3
mask13_6_0 = df['trial_id'] == 7
mask13_4_4 = df['trial_id'] == 9
mask13_2_4 = df['trial_id'] == 10
mask13_6_4 = df['trial_id'] == 11
mask6_4_4 = df['trial_id'] == 12
mask6_2_4 = df['trial_id'] == 13
mask6_6_4 = df['trial_id'] == 14
mask13_2_8 = df['trial_id'] == 15
mask13_4_8 = df['trial_id'] == 16


class Choose_sigma:
    def __init__(self, df):
        self.df = df
        self.df6_2 = self.df[mask6_2]
        self.df13_2 = self.df[mask13_2]
        self.df6_4 = self.df[mask6_4]
        self.df13_4 = self.df[mask13_4]
        self.df6_6 = self.df[mask6_6]
        self.df13_6 = self.df[mask13_6]
        self.df13_4_4 = self.df[mask13_4_4]
        self.df13_2_4 = self.df[mask13_2_4]
        self.df13_6_4 = self.df[mask13_6_4]
        self.df6_4_4 = self.df[mask6_4_4]
        self.df6_2_4 = self.df[mask6_2_4]
        self.df6_6_4 = self.df[mask6_6_4]
        self.df13_2_8 = self.df[mask13_2_8]
        self.df13_4_8 = self.df[mask13_4_8]

    def choose_id(self):
        self.list_1 = []
        self.list_2 = []
        self.list_3 = []
        self.list_4 = []
        self.list_5 = []
        self.list_6 = []
        self.list_7 = []
        self.list_8 = []
        self.list_9 = []
        self.list_10 = []
        self.list_11 = []
        self.list_12 = []
        self.list_13 = []
        self.list_14 = []
        self.list_15 = []
        self.list_16 = []
        self.list_17 = []
        self.list_18 = []
        self.list_19 = []
        self.list_20 = []
        for i in range(df.shape[0]):
            if df['unique_ID'].iloc[i][0:2] == '1_':
                self.list_1.append(i)
            if df['unique_ID'].iloc[i][0:2] == '2_':
                self.list_2.append(i)
            if df['unique_ID'].iloc[i][0:2] == '3_':
                self.list_3.append(i)
            if df['unique_ID'].iloc[i][0:2] == '4_':
                self.list_4.append(i)
            if df['unique_ID'].iloc[i][0:2] == '5_':
                self.list_5.append(i)
            if df['unique_ID'].iloc[i][0:2] == '6_':
                self.list_6.append(i)
            if df['unique_ID'].iloc[i][0:2] == '7_':
                self.list_7.append(i)
            if df['unique_ID'].iloc[i][0:2] == '8_':
                self.list_8.append(i)
            if df['unique_ID'].iloc[i][0:2] == '9_':
                self.list_9.append(i)
            if df['unique_ID'].iloc[i][0:2] == '10':
                self.list_10.append(i)
            if df['unique_ID'].iloc[i][0:2] == '11':
                self.list_11.append(i)
            if df['unique_ID'].iloc[i][0:2] == '12':
                self.list_12.append(i)
            if df['unique_ID'].iloc[i][0:2] == '13':
                self.list_13.append(i)
            if df['unique_ID'].iloc[i][0:2] == '14':
                self.list_14.append(i)
            if df['unique_ID'].iloc[i][0:2] == '15':
                self.list_15.append(i)
            if df['unique_ID'].iloc[i][0:2] == '16':
                self.list_16.append(i)
            if df['unique_ID'].iloc[i][0:2] == '17':
                self.list_17.append(i)
            if df['unique_ID'].iloc[i][0:2] == '18':
                self.list_18.append(i)
            if df['unique_ID'].iloc[i][0:2] == '19':
                self.list_19.append(i)
            if df['unique_ID'].iloc[i][0:2] == '20':
                self.list_20.append(i)

    def load_simlation(self, sim_file):
        if MultipleFiles == True:
            sim_df = pd.DataFrame()
            for filename in sim_file:
                df = pd.read_csv(filename)
                sim_df = pd.concat([sim_df, df], ignore_index=True)
        else:
            sim_df = pd.read_csv(sim_file)
        sim_df = sim_df.set_index('episode')
        # sim_df = sim_df.dropna(axis=0)
        sim_df = sim_df[sim_df['score'] == 1]
        gap3 = sim_df['time_gap'] == 2.3
        gap4 = sim_df['time_gap'] == 4.6
        gap5 = sim_df['time_gap'] == 6.9
        speed25 = sim_df['speed'] == 6.94
        speed30 = sim_df['speed'] == 13.89
        speed35 = sim_df['speed'] == 15.65
        acc0 = sim_df['acceleration'] == 0
        acc1 = sim_df['acceleration'] == 2.02
        acc2 = sim_df['acceleration'] == 3.47
        acc3 = sim_df['acceleration'] == 4.05
        acc4 = sim_df['acceleration'] == 0.87
        acc5 = sim_df['acceleration'] == 1.62
        acc6 = sim_df['acceleration'] == 1.73
        acc7 = sim_df['acceleration'] == 0.55
        acc8 = sim_df['acceleration'] == 1.06

        self.start6_2 = sim_df['start_time'][speed25 & gap3 & acc0].tolist()
        self.start6_2.sort()
        self.start6_4 = sim_df['start_time'][speed25 & gap4 & acc0].tolist()
        self.start6_4.sort()

        self.start6_6 = sim_df['start_time'][speed25 & gap5 & acc0].tolist()
        self.start6_6.sort()
        self.start13_2 = sim_df['start_time'][speed30 & gap3 & acc0].tolist()
        self.start13_2.sort()
        self.start13_4 = sim_df['start_time'][speed30 & gap4 & acc0].tolist()
        self.start13_4.sort()
        self.start13_6 = sim_df['start_time'][speed30 & gap5 & acc0].tolist()
        self.start13_6.sort()

        self.start6_2_4 = sim_df['start_time'][speed25 & gap3 & acc1].tolist()
        self.start6_2_4.sort()
        self.start13_2_4 = sim_df['start_time'][speed30 & gap3 & acc2].tolist()
        self.start13_2_4.sort()
        self.start13_2_8 = sim_df['start_time'][speed30 & gap3 & acc3].tolist()
        self.start13_2_8.sort()
        self.start6_4_4 = sim_df['start_time'][speed25 & gap4 & acc4].tolist()
        self.start6_4_4.sort()
        self.start13_4_4 = sim_df['start_time'][speed30 & gap4 & acc5].tolist()
        self.start13_4_4.sort()
        self.start13_4_8 = sim_df['start_time'][speed30 & gap4 & acc6].tolist()
        self.start13_4_8.sort()
        self.start6_6_4 = sim_df['start_time'][speed25 & gap5 & acc7].tolist()
        self.start6_6_4.sort()
        self.start13_6_4 = sim_df['start_time'][speed30 & gap5 & acc8].tolist()
        self.start13_6_4.sort()

def compute_prob_density(sim_data, exp_data, bandwidth=1.0, kernel='gaussian'):
    # Reshape simulated data for sklearn
    if len(sim_data) == 0:
        return 0
    sim_data = np.array(sim_data).reshape(-1, 1)

    # Instantiate and fit the KDE model
    kde = KernelDensity(bandwidth=bandwidth, kernel=kernel)
    kde.fit(sim_data)
    log_prob_exp = kde.score_samples(np.array(exp_data).reshape(1, -1))

    # Convert log probability density to actual probability density
    prob_density_exp = np.exp(log_prob_exp)
    prob_density_exp = np.clip(prob_density_exp, 0.01, 1)

    return prob_density_exp[0]

choose = Choose_sigma(df)
choose.choose_id()
sigma_intervals = 11

sigmas = np.linspace(0, 1, sigma_intervals)
sigmas = sigmas[1:]
# sigmas = [0.01, 0.02, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.09, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]

sim_dict = {}
sim_csv_dir = f'../Sim_Data/DQN_Sigma_Input/Sim_data_{model_num}_Delay_Dec'

for sigma in sigmas:
    sigma = round(sigma, 3)
    print(f'sigma:{sigma}')

    i = None
    csvname = f'Sigma_{sigma}_Input_{input}_Test{i}.csv'
    csv_file = os.path.join(sim_csv_dir, csvname)
    choose.load_simlation(csv_file)
    sim_dict[f'ct_{sigma}_6_2'] = choose.start6_2
    sim_dict[f'ct_{sigma}_13_2'] = choose.start13_2
    sim_dict[f'ct_{sigma}_6_4'] = choose.start6_4
    sim_dict[f'ct_{sigma}_13_4'] = choose.start13_4
    sim_dict[f'ct_{sigma}_6_6'] = choose.start6_6
    sim_dict[f'ct_{sigma}_13_6'] = choose.start13_6

    sim_dict[f'ct_{sigma}_6_2_4'] = choose.start6_2_4
    sim_dict[f'ct_{sigma}_13_2_4'] = choose.start13_2_4
    sim_dict[f'ct_{sigma}_13_2_8'] = choose.start13_2_8

    sim_dict[f'ct_{sigma}_6_4_4'] = choose.start6_4_4
    sim_dict[f'ct_{sigma}_13_4_4'] = choose.start13_4_4
    sim_dict[f'ct_{sigma}_13_4_8'] = choose.start13_4_8

    sim_dict[f'ct_{sigma}_6_6_4'] = choose.start6_6_4
    sim_dict[f'ct_{sigma}_13_6_4'] = choose.start13_6_4

ID_list = []
id = 1
Sigma_IT_list = []

for i in [choose.list_1, choose.list_2, choose.list_3, choose.list_4, choose.list_5,
          choose.list_6, choose.list_7, choose.list_8, choose.list_9, choose.list_10,
          choose.list_11, choose.list_12, choose.list_13, choose.list_14, choose.list_15,
          choose.list_16, choose.list_17, choose.list_18, choose.list_19, choose.list_20]:
    print(f'id:{id}')

    # for s in range(intervals):
    Dis = []
    Sigma_IT_value = []

    exp_6_2 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 6]['cross_time'].tolist()
    exp_6_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 4]['cross_time'].tolist()
    exp_13_2 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 5]['cross_time'].tolist()
    exp_13_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 3]['cross_time'].tolist()
    exp_6_6 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 8]['cross_time'].tolist()
    exp_13_6 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 7]['cross_time'].tolist()

    exp_6_2_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 13]['cross_time'].tolist()
    exp_13_2_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 10]['cross_time'].tolist()
    exp_13_2_8 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 15]['cross_time'].tolist()
    exp_6_4_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 12]['cross_time'].tolist()
    exp_13_4_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 9]['cross_time'].tolist()
    exp_13_4_8 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 16]['cross_time'].tolist()
    exp_6_6_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 14]['cross_time'].tolist()
    exp_13_6_4 = choose.df.iloc[i][choose.df.iloc[i]['trial_id'] == 11]['cross_time'].tolist()

    for sigma in sigmas:
        sigma = round(sigma, 3)


        print(f'sigma:{sigma}')
        Sigma_IT = [sigma]
        Sigma_IT_value.append(Sigma_IT)

        sim_6_2 = sim_dict[f'ct_{sigma}_6_2']
        prob6_2 = compute_prob_density(sim_6_2,exp_6_2)
        sim_13_2 = sim_dict[f'ct_{sigma}_13_2']
        prob13_2 = compute_prob_density(sim_13_2,exp_13_2)
        sim_6_4 = sim_dict[f'ct_{sigma}_6_4']
        prob6_4 = compute_prob_density(sim_6_4,exp_6_4)
        sim_13_4 = sim_dict[f'ct_{sigma}_13_4']
        prob13_4 = compute_prob_density(sim_13_4,exp_13_4)
        sim_6_6 = sim_dict[f'ct_{sigma}_6_6']
        prob6_6 = compute_prob_density(sim_6_6,exp_6_6)
        sim_13_6 = sim_dict[f'ct_{sigma}_13_6']
        prob13_6 = compute_prob_density(sim_13_6,exp_13_6)

        sim_6_2_4 = sim_dict[f'ct_{sigma}_6_2_4']
        prob6_2_4 = compute_prob_density(sim_6_2_4,exp_6_2_4)
        sim_13_2_4 = sim_dict[f'ct_{sigma}_13_2_4']
        prob13_2_4 = compute_prob_density(sim_13_2_4,exp_13_2_4)

        sim_13_2_8 = sim_dict[f'ct_{sigma}_13_2_8']
        prob13_2_8 = compute_prob_density(sim_13_2_8,exp_13_2_8)

        sim_13_4_4 = sim_dict[f'ct_{sigma}_13_4_4']
        prob13_4_4 = compute_prob_density(sim_13_4_4,exp_13_4_4)

        sim_6_4_4 = sim_dict[f'ct_{sigma}_6_4_4']
        prob6_4_4 = compute_prob_density(sim_6_4_4,exp_6_4_4)

        sim_13_4_8 = sim_dict[f'ct_{sigma}_13_4_8']
        prob13_4_8 = compute_prob_density(sim_13_4_8,exp_13_4_8)

        sim_6_6_4 = sim_dict[f'ct_{sigma}_6_6_4']
        prob6_6_4 = compute_prob_density(sim_6_6_4,exp_6_6_4)

        sim_13_6_4 = sim_dict[f'ct_{sigma}_13_6_4']
        prob13_6_4  = compute_prob_density(sim_13_6_4 ,exp_13_6_4 )
        #
        sum_dis = prob6_2 * prob13_2 * prob6_4 * prob13_4 * prob6_6 * prob13_6 * prob6_2_4 * prob13_2_4 * prob13_2_8 \
                  * prob6_4_4 * prob13_4_4 * prob13_4_8 * prob6_6_4 * prob13_6_4

        Dis.append(sum_dis)


    print(Sigma_IT_value[Dis.index(max(Dis))])
    Sigma_IT_list.append(Sigma_IT_value[Dis.index(max(Dis))])
    ID_list.append(id)
    id += 1


    data = {'Id': ID_list,
            'Sigma': [row[0] for row in Sigma_IT_list],
            }
    df_SIGMA_LIST = pd.DataFrame(data)
    csv_dir = 'ID_Sigma'
    os.makedirs(csv_dir, exist_ok=True)

    csvname = f'ID_Sigma_{model_num}_Dec.csv'
    csv_file = os.path.join(csv_dir, csvname)
    df_SIGMA_LIST.to_csv(csv_file)

endtime1 = datetime.datetime.now()
print(Sigma_IT_list)
print(ID_list)
print(endtime1 - starttime1)
